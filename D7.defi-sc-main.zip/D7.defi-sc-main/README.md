# D7.defi-sc

The project consists of following components:<p>
[Blockchain event ETL service](https://github.deutsche-boerse.de/dev/D7.defi-sc/blob/develop/app/bc-event-etl/README.md)<p>
[Off-chain event storage service](https://github.deutsche-boerse.de/dev/D7.defi-sc/blob/develop/app/off-chain-event-storage/README.md)<p>
[Smart contracts service](https://github.deutsche-boerse.de/dev/D7.defi-sc/tree/develop/app/smart-contracts#readme)<p>
Mock event module<p>