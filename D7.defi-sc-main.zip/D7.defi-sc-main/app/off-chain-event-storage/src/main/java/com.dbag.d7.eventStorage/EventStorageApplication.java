package com.dbag.d7.eventStorage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventStorageApplication {

    public static void main(String[] args) {
        SpringApplication.run(EventStorageApplication.class, args);
        System.out.println("Welcome to our application");
    }
}
