package com.dbag.d7.events;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.dbag.d7.events")
public class SynchronousSpringEventsConfig {

}
