package com.dbag.d7.events;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;
import org.web3j.abi.EventEncoder;
import org.web3j.abi.TypeEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Address;
import org.web3j.abi.datatypes.Event;
import org.web3j.abi.datatypes.generated.Uint256;
import org.web3j.protocol.core.methods.response.Log;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import static java.lang.Thread.*;

@Component
public class MockBlockchainEventPublisher {

    @Autowired
    private ApplicationEventPublisher applicationEventPublisher;

    final Event transferEvent = new Event("Transfer",
            Arrays.asList(
                    new TypeReference<Address>(true) {
                    },
                    new TypeReference<Address>(true) {
                    },
                    new TypeReference<Uint256>(false) {
                    }));

    final Event approvalEvent = new Event("Approval",
            Arrays.asList(
                    new TypeReference<Address>(true) {
                    },
                    new TypeReference<Address>(true) {
                    },
                    new TypeReference<Uint256>(false) {
                    }));

    private String encodedEvent;
    private Log log = new Log();
    private final List<String> topics = new ArrayList<>();

    public void sendEmptyEvent(){
        log = new Log();
        System.out.println("Publishing empty event" + log);

        final MockBlockchainEvent mockBlockchainEvent = new MockBlockchainEvent(this, log);
        applicationEventPublisher.publishEvent(mockBlockchainEvent);
    }

    public void sendEvents(Address address, Address from, Address to, Uint256 value, Event event) {
        // Encode the event
        encodedEvent = EventEncoder.encode(event);

        log = new Log();
        log.setAddress(address.toString());
        log.setBlockNumber("123456");
        log.setTransactionHash("0x123456789");

        topics.clear();
        topics.add(encodedEvent);
        topics.add(TypeEncoder.encode(from));
        topics.add(TypeEncoder.encode(to));
        topics.add(TypeEncoder.encode(value));
        log.setTopics(topics);

        System.out.println("Publishing transfer event " + log);
        final MockBlockchainEvent mockBlockchainEvent = new MockBlockchainEvent(this, log);
        applicationEventPublisher.publishEvent(mockBlockchainEvent);
    }

    public void randomEventsPublisher() throws InterruptedException {
        Random random = new Random();
        int aux;

        for(int i = 0; i < 10; i++) {
            sleep(10);
            aux = random.nextInt(6);
            switch (aux) {
                case 0 -> sendEvents(new Address("0x0000000000000000000000000000000000001010"), new Address("0x00123"),
                        new Address("0x00321"), new Uint256(15), approvalEvent);
                case 1 -> sendEvents(new Address("0x0000000000000000000000000000000000001010"), new Address("0x00423"),
                        new Address("0x00821"), new Uint256(100), transferEvent);
                case 2 -> sendEvents(new Address("0x0000000000000000000000000000000000001010"), new Address("0x10423"),
                        new Address("0x20821"), new Uint256(120), approvalEvent);
                case 3 -> sendEvents(new Address("0x0000000000000000000000000000000000001011"), new Address("0x10423"),
                        new Address("0x20822"), new Uint256(200),transferEvent);
                case 4 -> sendEvents(new Address("0x0000000000000000000000000000000000001012"), new Address("0x10423"),
                        new Address("0x20822"), new Uint256(200),approvalEvent);
            }
        }
    }
}