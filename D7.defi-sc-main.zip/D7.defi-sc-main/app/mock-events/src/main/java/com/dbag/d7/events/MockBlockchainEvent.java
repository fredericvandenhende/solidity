package com.dbag.d7.events;

import org.springframework.context.ApplicationEvent;
import org.web3j.protocol.core.methods.response.Log;

public class MockBlockchainEvent extends ApplicationEvent {

    private final Log log;

    public MockBlockchainEvent(final Object source, final Log log) {
        super(source);
        this.log = log;
    }

    public Log getMessage() {
        return log;
    }
}
