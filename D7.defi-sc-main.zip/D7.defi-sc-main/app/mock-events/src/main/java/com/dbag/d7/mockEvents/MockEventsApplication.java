package com.dbag.d7.mockEvents;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages={"com.dbag.d7.events"})
public class MockEventsApplication {
	public static void main(String[] args) {
		SpringApplication.run(MockEventsApplication.class, args);
	}

}
