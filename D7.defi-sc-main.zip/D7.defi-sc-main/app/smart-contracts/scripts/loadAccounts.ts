import { ethers } from "hardhat";

require("dotenv").config();

export default async function loadAccounts() {
  const accounts = await ethers.getSigners();

  // Set accounts

  const registrar = accounts[0];
  const issuerSeller = process.env.ISSUER_SELLER;
  const investorBuyer = process.env.INVESTOR_BUYER;

  return { registrar, issuerSeller, investorBuyer };
}
