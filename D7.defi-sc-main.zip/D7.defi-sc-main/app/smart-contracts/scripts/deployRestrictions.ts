import { ethers } from "hardhat";
import loadAccounts from "./loadAccounts";

async function main() {
  // Load accounts

  const { registrar } = await loadAccounts();

  // Deploy Restrictions

  const restrictions = await ethers.deployContract("Restrictions", {
    from: registrar,
  });

  console.log("Deploying Restrictions contract. Waiting confirmation...");

  await restrictions.waitForDeployment();

  console.log(
    `Restrictions contract deployed successfully!\nAddress: ${await restrictions.getAddress()}`
  );
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
