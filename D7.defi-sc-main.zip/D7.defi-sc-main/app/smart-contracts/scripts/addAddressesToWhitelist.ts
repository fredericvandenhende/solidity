import { ethers } from "hardhat";
import loadAccounts from "./loadAccounts";

require("dotenv").config();

const restrictionsArtifact = require("../artifacts/contracts/Restrictions.sol/Restrictions.json");

async function main() {
  // Load accounts

  const { registrar, investorBuyer } = await loadAccounts();

  // Load Restrictions contract

  const restrictions = new ethers.Contract(
    process.env.RESTRICTIONS_CONTRACT!,
    restrictionsArtifact.abi,
    registrar
  );

  // Add accounts to the whitelist

  console.log("Adding accounts to the whitelist. Waiting confirmation...");

  await (await restrictions.addWhitelistAddress([investorBuyer])).wait();

  console.log("Accouns was added to the whitelist successfully!");
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
