import { ethers } from "hardhat";
import loadAccounts from "./loadAccounts";

require("dotenv").config();

async function main() {
  // Load accounts

  const { registrar, issuerSeller } = await loadAccounts();

  // Deploy CommercialPaper

  const commercialPaper = await ethers.deployContract(
    "CommercialPaper",
    [
      true,
      "Digital Security 1",
      "DE1234ABCD56",
      "DE1234ABCD56",
      "Germany",
      "EUR",
      "31/12/2023",
      1000,
      "https://example.com/securityUri",
      "F70460D4D381FCC8DFD30DEF44993BD4952E3EB71E50CA4372D77F274AE1CBF2", // ethers.sha256(ethers.randomBytes(30)),
      100000,
      process.env.RESTRICTIONS_CONTRACT,
      issuerSeller,
    ],
    { from: registrar }
  );

  console.log(`Deploying CommercialPaper contract. Waiting confirmation...`);

  await commercialPaper.waitForDeployment();

  console.log(
    `${await commercialPaper.name()} deployed successfully!\nAddress: ${await commercialPaper.getAddress()}`
  );
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
