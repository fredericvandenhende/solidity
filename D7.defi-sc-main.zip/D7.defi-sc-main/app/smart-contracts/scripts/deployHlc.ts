import { ethers } from "hardhat";
import loadAccounts from "./loadAccounts";

require("dotenv").config();

const restrictionsArtifact = require("../artifacts/contracts/Restrictions.sol/Restrictions.json");

async function main() {
  // Load accounts

  const { registrar, issuerSeller, investorBuyer } = await loadAccounts();

  // Deploy HLC

  const hlc = await ethers.deployContract(
    "HLC",
    [
      issuerSeller,
      investorBuyer,
      99, // <-- price
      1000, // <-- token_amount
      ethers.hexlify(ethers.toUtf8Bytes("TIPS_ID")), // <-- tips
      ethers.sha256(ethers.toUtf8Bytes("Exec key")),
      ethers.sha256(ethers.toUtf8Bytes("Canc key")),
      process.env.COMMERCIAL_PAPER_CONTRACT,
    ],
    { from: registrar }
  );

  console.log(`Deploying HLC contract. Waiting confirmation...`);

  await hlc.waitForDeployment();

  console.log(`HLC deployed successfully!\nAddress: ${await hlc.getAddress()}\n`);

  // Load Restrictions contract

  const restrictions = new ethers.Contract(
    process.env.RESTRICTIONS_CONTRACT!,
    restrictionsArtifact.abi,
    registrar
  );

  console.log("Adding the HLC contract to the whitelist. Waiting confirmation...");

  // Add HLC contract to whitelist

  await (await restrictions.addWhitelistAddress([hlc.getAddress()])).wait();

  console.log("HLC contract was added to the whitelist successfully!");
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
