import { loadFixture } from "@nomicfoundation/hardhat-toolbox/network-helpers";
import { expect } from "chai";
import { ethers } from "hardhat";
import { Restrictions } from "../typechain-types/contracts/Restrictions";
import { RestrictionsAccounts } from "./types";

describe("Restrictions", () => {
  async function deployRestrictionsFixture() {
    const Restrictions = await ethers.getContractFactory("Restrictions");

    const signers = await ethers.getSigners();

    const accounts: RestrictionsAccounts = {
      registrar: signers[0],
      issuer: signers[1],
      notARegistrar: signers[2],
      registrarToBeAdded: signers[3],
      issuerToBeAdded: signers[4],
      whitelistToBeAddedA: signers[5],
      whitelistToBeAddedB: signers[6],
      whitelistToBeAddedC: signers[7],
      investorA: signers[8],
      investorB: signers[9],
      investorC: signers[10],
    };

    const restrictions = await Restrictions.connect(
      accounts.registrar
    ).deploy();

    await restrictions.addWhitelistAddress([
      accounts.issuer,
      accounts.investorA,
      accounts.investorB,
      accounts.investorC,
      accounts.registrarToBeAdded,
    ]);

    return {
      accounts,
      restrictions,
    };
  }

  let restrictions: Restrictions;

  let accounts: RestrictionsAccounts;

  let REGISTRAR_ADMIN_ROLE: string;

  let REGISTRAR_ROLE: string;

  beforeEach(async () => {
    const fixture = await loadFixture(deployRestrictionsFixture);

    accounts = fixture.accounts;
    restrictions = fixture.restrictions;

    REGISTRAR_ADMIN_ROLE = await restrictions.REGISTRAR_ADMIN();

    REGISTRAR_ROLE = await restrictions.REGISTRAR();
  });

  describe("Deployment", () => {
    it("Should set REGISTRAR role to the deployer account", async () => {
      expect(await restrictions.hasRole(REGISTRAR_ROLE, accounts.registrar)).to
        .be.true;
    });

    it("Should set REGISTRAR_ADMIN role to the deployer account", async () => {
      expect(
        await restrictions.hasRole(REGISTRAR_ADMIN_ROLE, accounts.registrar)
      ).to.be.true;
    });

    it("Should set REGISTRAR_ADMIN as admin role for REGISTRAR role", async () => {
      expect(await restrictions.getRoleAdmin(REGISTRAR_ROLE)).to.be.equal(
        REGISTRAR_ADMIN_ROLE
      );
    });

    it("Should set false to isGlobalPaused", async () => {
      expect(await restrictions.paused()).to.be.false;
    });
  });

  describe("addRegistrar", () => {
    describe("Success Test Case", () => {
      beforeEach(async () => {
        await restrictions.addRegistrar(accounts.registrarToBeAdded);
      });

      it("Should assign REGISTRAR role to the provided account", async () => {
        expect(
          await restrictions.hasRole(
            REGISTRAR_ROLE,
            accounts.registrarToBeAdded
          )
        ).to.be.true;
      });

      it("Should assign REGISTRAR_ADMIN role to the provided account", async () => {
        expect(
          await restrictions.hasRole(
            REGISTRAR_ADMIN_ROLE,
            accounts.registrarToBeAdded
          )
        ).to.be.true;
      });
    });

    it("Should revert if caller isn't a registrar account", async () => {
      await expect(
        restrictions
          .connect(accounts.notARegistrar)
          .addRegistrar(accounts.registrarToBeAdded.address)
      ).to.be.revertedWith("caller is not a registrar");
    });
  });

  describe("removeRegistrar", () => {
    it("Should remove REGISTRAR role from the provided accounts", async () => {
      await restrictions.removeRegistrar(accounts.registrar);

      expect(await restrictions.hasRole(REGISTRAR_ROLE, accounts.registrar)).to
        .be.false;
    });

    it("Should revert if caller isn't a registrar account", async () => {
      await expect(
        restrictions
          .connect(accounts.notARegistrar)
          .removeRegistrar(accounts.registrarToBeAdded)
      ).to.be.revertedWith("caller is not a registrar");
    });
  });

  describe("addWhitelistAddress", () => {
    it("Should add the accounts to the whitelist", async () => {
      await restrictions
        .connect(accounts.registrar)
        .addWhitelistAddress([
          accounts.whitelistToBeAddedA,
          accounts.whitelistToBeAddedB,
          accounts.whitelistToBeAddedC,
        ]);
      expect(await restrictions.isWhitelisted(accounts.whitelistToBeAddedA)).to
        .be.true;
      expect(await restrictions.isWhitelisted(accounts.whitelistToBeAddedB)).to
        .be.true;
      expect(await restrictions.isWhitelisted(accounts.whitelistToBeAddedC)).to
        .be.true;
    });
    it("Should revert if caller isn't a registrar account", async () => {
      await expect(
        restrictions
          .connect(accounts.notARegistrar)
          .addWhitelistAddress([
            accounts.whitelistToBeAddedA,
            accounts.whitelistToBeAddedB,
            accounts.whitelistToBeAddedC,
          ])
      ).to.be.revertedWith("caller is not a registrar");
    });
  });

  describe("isWhitelisted", () => {
    it("Should return false if an account is not in the whitelist", async () => {
      expect(
        await restrictions
          .connect(accounts.notARegistrar)
          .isWhitelisted(accounts.whitelistToBeAddedA)
      ).to.be.false;
    });
    it("Should return true if an account is in the whitelist", async () => {
      expect(
        await restrictions
          .connect(accounts.notARegistrar)
          .isWhitelisted(accounts.investorA)
      ).to.be.true;
    });
  });

  describe("removeWhitelistAddress", () => {
    it("Should remove the accounts from the whitelist", async () => {
      await restrictions
        .connect(accounts.registrar)
        .removeWhitelistAddress([
          accounts.investorA,
          accounts.investorB,
          accounts.investorC,
        ]);
      expect(await restrictions.isWhitelisted(accounts.investorA)).to.be.false;
      expect(await restrictions.isWhitelisted(accounts.investorB)).to.be.false;
      expect(await restrictions.isWhitelisted(accounts.investorC)).to.be.false;
    });
    it("Should revert if caller isn't a registrar account", async () => {
      await expect(
        restrictions
          .connect(accounts.notARegistrar)
          .addWhitelistAddress([
            accounts.investorA,
            accounts.investorB,
            accounts.investorC,
          ])
      ).to.be.revertedWith("caller is not a registrar");
    });
  });

  describe("pauseAll", () => {
    it("Should set isGlobalPaused to true if contract isn't paused", async () => {
      await restrictions.pauseAll();
      expect(await restrictions.paused()).to.be.true;
    });

    it("Should revert if isGlobalPaused is true", async () => {
      await restrictions.pauseAll();
      expect(await restrictions.paused()).to.be.true;

      await expect(restrictions.pauseAll()).to.be.revertedWith(
        "Pausable: paused"
      );
    });

    it("Should revert if caller isn't a registrar account", async () => {
      await expect(
        restrictions.connect(accounts.notARegistrar).pauseAll()
      ).to.be.revertedWith("caller is not a registrar");
    });
  });

  describe("unpauseAll", () => {
    it("Should set isGlobalPaused to false if contract is paused", async () => {
      await restrictions.pauseAll();
      expect(await restrictions.paused()).to.be.true;
      await restrictions.unpauseAll();
      expect(await restrictions.paused()).to.be.false;
    });

    it("Should revert if isGlobalPaused is false", async () => {
      await expect(restrictions.unpauseAll()).to.be.revertedWith(
        "Pausable: not paused"
      );
    });

    it("Should revert if caller isn't a registrar account", async () => {
      await expect(
        restrictions.connect(accounts.notARegistrar).unpauseAll()
      ).to.be.revertedWith("caller is not a registrar");
    });
  });
});
