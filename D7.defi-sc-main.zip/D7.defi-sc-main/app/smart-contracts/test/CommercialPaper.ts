import { loadFixture } from "@nomicfoundation/hardhat-toolbox/network-helpers";
import { expect } from "chai";
import { ethers } from "hardhat";
import { CommercialPaper } from "../typechain-types/contracts/CommercialPaper";
import { Restrictions } from "../typechain-types/contracts/";

import { CommercialPaperAccounts, CommercialPaperArgs } from "./types";

// TODO: Add test cases for registrarB for all functions

// TODO: Add test cases with issuers that were not whitelisted yet

// TODO: Add test cases with whitelisted accounts that are not issuers

describe("CommercialPaper", () => {
  async function deployPreliminaryCommercialPaperFixture() {
    const Restrictions = await ethers.getContractFactory("Restrictions");
    const CommercialPaper = await ethers.getContractFactory("CommercialPaper");

    const signers = await ethers.getSigners();

    const accounts: CommercialPaperAccounts = {
      registrarA: signers[0],
      registrarB: signers[1],
      issuerA: signers[2],
      issuerB: signers[3],
      notARegistrar: signers[4],
      notAnIssuer: signers[5],
      notWhitelisted: signers[6],
      investorA: signers[7],
      investorB: signers[8],
      issuerToBeAdded: signers[9],
    };

    const restrictions = await Restrictions.connect(
      accounts.registrarA
    ).deploy();

    const commercialPaperArgs: CommercialPaperArgs = {
      isLive: false,
      name: "CommercialPaper",
      symbol: "CPP",
      isin: "CPP",
      issuanceCountry: "Germany",
      currency: "EUR",
      maturity: "2024-08-10T18:00:00.000Z",
      minimumDenomination: 10,
      addInfoUri: "https://example.com/addInfoURI",
      checksum:
        "F70460D4D381FCC8DFD30DEF44993BD4952E3EB71E50CA4372D77F274AE1CBF2",
      cap: 1000000,
      restrictionsSmartContract: await restrictions.getAddress(),
      issuer: accounts.issuerA.address,
    };

    const commercialPaper = await CommercialPaper.connect(
      accounts.registrarA
    ).deploy(
      commercialPaperArgs.isLive,
      commercialPaperArgs.name,
      commercialPaperArgs.symbol,
      commercialPaperArgs.isin,
      commercialPaperArgs.issuanceCountry,
      commercialPaperArgs.currency,
      commercialPaperArgs.maturity,
      commercialPaperArgs.minimumDenomination,
      commercialPaperArgs.addInfoUri,
      commercialPaperArgs.checksum,
      commercialPaperArgs.cap,
      commercialPaperArgs.restrictionsSmartContract,
      commercialPaperArgs.issuer
    );

    // Add whitelisted addresses
    await restrictions
      .connect(accounts.registrarA)
      .addWhitelistAddress([
        accounts.registrarB,
        accounts.issuerA,
        accounts.issuerB,
        accounts.investorA,
        accounts.investorB,
        accounts.issuerToBeAdded,
      ]);

    // Add registrar
    await restrictions
      .connect(accounts.registrarA)
      .addRegistrar(accounts.registrarB);

    // Add issuers
    await commercialPaper
      .connect(accounts.registrarA)
      .addIssuer(accounts.issuerA);
    await commercialPaper
      .connect(accounts.registrarA)
      .addIssuer(accounts.issuerB);

    return { accounts, commercialPaper, commercialPaperArgs, restrictions };
  }

  async function deployLiveCommercialPaperFixture() {
    const Restrictions = await ethers.getContractFactory("Restrictions");
    const CommercialPaper = await ethers.getContractFactory("CommercialPaper");

    const signers = await ethers.getSigners();

    const accounts: CommercialPaperAccounts = {
      registrarA: signers[0],
      registrarB: signers[1],
      issuerA: signers[2],
      issuerB: signers[3],
      notARegistrar: signers[4],
      notAnIssuer: signers[5],
      notWhitelisted: signers[6],
      investorA: signers[7],
      investorB: signers[8],
      issuerToBeAdded: signers[9],
    };

    const restrictions = await Restrictions.connect(
      accounts.registrarA
    ).deploy();

    const commercialPaperArgs: CommercialPaperArgs = {
      isLive: true,
      name: "CommercialPaper",
      symbol: "CPP",
      isin: "CPP",
      issuanceCountry: "Germany",
      currency: "EUR",
      maturity: "2024-08-10T18:00:00.000Z",
      minimumDenomination: 10,
      addInfoUri: "https://example.com/addInfoURI",
      checksum:
        "F70460D4D381FCC8DFD30DEF44993BD4952E3EB71E50CA4372D77F274AE1CBF2",
      cap: 1000,
      restrictionsSmartContract: await restrictions.getAddress(),
      issuer: accounts.issuerA.address,
    };

    const commercialPaper = await CommercialPaper.connect(
      accounts.registrarA
    ).deploy(
      commercialPaperArgs.isLive,
      commercialPaperArgs.name,
      commercialPaperArgs.symbol,
      commercialPaperArgs.isin,
      commercialPaperArgs.issuanceCountry,
      commercialPaperArgs.currency,
      commercialPaperArgs.maturity,
      commercialPaperArgs.minimumDenomination,
      commercialPaperArgs.addInfoUri,
      commercialPaperArgs.checksum,
      commercialPaperArgs.cap,
      commercialPaperArgs.restrictionsSmartContract,
      commercialPaperArgs.issuer
    );

    // Add whitelisted addresses
    await restrictions
      .connect(accounts.registrarA)
      .addWhitelistAddress([
        accounts.issuerA,
        accounts.issuerB,
        accounts.investorA,
        accounts.investorB,
        accounts.registrarB,
      ]);

    // Add registrar
    await restrictions
      .connect(accounts.registrarA)
      .addRegistrar(accounts.registrarB);

    // Add issuers
    await commercialPaper
      .connect(accounts.registrarA)
      .addIssuer(accounts.issuerA);
    await commercialPaper
      .connect(accounts.registrarA)
      .addIssuer(accounts.issuerB);

    return { accounts, commercialPaper, commercialPaperArgs, restrictions };
  }

  let commercialPaper: CommercialPaper;
  let commercialPaperArgs: CommercialPaperArgs;
  let restrictions: Restrictions;
  let accounts: CommercialPaperAccounts;

  let ISSUER_ADMIN_ROLE: string;
  let ISSUER_ROLE: string;

  describe("Deployment Live Status", () => {
    it("Should set CommercialPaper status to Live", async () => {
      const fixture = await loadFixture(deployLiveCommercialPaperFixture);

      commercialPaper = fixture.commercialPaper;

      expect(await commercialPaper.status()).to.equal(1); // Status.Live
    });
  });

  describe("Deployment Preliminary Status", () => {
    beforeEach(async () => {
      const fixture = await loadFixture(
        deployPreliminaryCommercialPaperFixture
      );

      accounts = fixture.accounts;
      commercialPaper = fixture.commercialPaper;
      commercialPaperArgs = fixture.commercialPaperArgs;
      restrictions = fixture.restrictions;

      ISSUER_ADMIN_ROLE = await commercialPaper.ISSUER_ADMIN();
      ISSUER_ROLE = await commercialPaper.ISSUER();
    });

    it("Should set ISSUER_ADMIN role to the deployer account", async () => {
      expect(
        await commercialPaper.hasRole(ISSUER_ADMIN_ROLE, accounts.registrarA)
      ).to.be.true;
    });

    it("Should set ISSUER_ADMIN as admin role for ISSUER role", async () => {
      expect(await commercialPaper.getRoleAdmin(ISSUER_ROLE)).to.be.equal(
        ISSUER_ADMIN_ROLE
      );
    });

    it("Should set the right CommercialPaper name", async () => {
      expect(await commercialPaper.name()).to.equal(commercialPaperArgs.name);
    });

    it("Should set the right CommercialPaper symbol", async () => {
      expect(await commercialPaper.symbol()).to.equal(
        commercialPaperArgs.symbol
      );
    });

    it("Should set the right CommercialPaper decimals", async () => {
      expect(await commercialPaper.decimals()).to.equal(0);
    });

    it("Should set the right CommercialPaper isin", async () => {
      expect(await commercialPaper.isin()).to.equal(commercialPaperArgs.isin);
    });

    it("Should set the right CommercialPaper security type", async () => {
      expect(await commercialPaper.securityType()).to.equal(
        0 // CommercialPaper
      );
    });

    it("Should set the right CommercialPaper issuance country", async () => {
      expect(await commercialPaper.issuanceCountry()).to.equal(
        commercialPaperArgs.issuanceCountry
      );
    });

    it("Should set the right CommercialPaper currency", async () => {
      expect(await commercialPaper.currency()).to.equal(
        commercialPaperArgs.currency
      );
    });

    it("Should set the right CommercialPaper maturity date", async () => {
      expect(await commercialPaper.maturity()).to.equal(
        commercialPaperArgs.maturity
      );
    });

    it("Should set the right CommercialPaper minimumDenomination value", async () => {
      expect(await commercialPaper.minimumDenomination()).to.equal(
        commercialPaperArgs.minimumDenomination
      );
    });

    it("Should set the right CommercialPaper addInfoURI", async () => {
      expect(await commercialPaper.addInfoUri()).to.equal(
        commercialPaperArgs.addInfoUri
      );
    });

    it("Should set the right CommercialPaper checksum", async () => {
      expect(await commercialPaper.checksum()).to.equal(
        commercialPaperArgs.checksum
      );
    });

    it("Should set the right CommercialPaper volume cap", async () => {
      expect(await commercialPaper.cap()).to.equal(commercialPaperArgs.cap);
    });

    it("Should set the right CommercialPaper restrictions Smart Contract", async () => {
      expect(await commercialPaper.restrictionsSmartContract()).to.equal(
        commercialPaperArgs.restrictionsSmartContract
      );
    });

    it("Should set the right CommercialPaper total supply", async () => {
      expect(await commercialPaper.totalSupply()).to.equal(0);
    });

    it("Should set the right CommercialPaper issuer", async () => {
      expect(await commercialPaper.issuer()).to.equal(
        commercialPaperArgs.issuer
      );
    });

    it("Should set the CommercialPaper status to Preliminary", async () => {
      expect(await commercialPaper.status()).to.equal(0); // Status.Preliminary
    });

    it("Should set the right CommercialPaper paused status", async () => {
      expect(await commercialPaper.paused()).to.equal(false);
    });

    it("All the accounts balance should be zero", async () => {
      Object.values(accounts).forEach(async (account) => {
        expect(await commercialPaper.balanceOf(account)).to.equal(1);
      });
    });

    // ERC20 functions

    describe("name", () => {
      it("Should return the CommercialPaper name", async () => {
        expect(await commercialPaper.name()).to.equal(commercialPaperArgs.name);
      });
    });

    describe("symbol", () => {
      it("Should return the CommercialPaper symbol", async () => {
        expect(await commercialPaper.symbol()).to.equal(
          commercialPaperArgs.symbol
        );
      });
    });

    describe("decimals", () => {
      it("Should return the CommercialPaper decimals", async () => {
        expect(await commercialPaper.decimals()).to.equal(0);
      });
    });

    describe("totalSupply", () => {
      it("Should return the CommercialPaper totalSupply", async () => {
        expect(await commercialPaper.totalSupply()).to.equal(0);
      });
    });

    describe("balanceOf", () => {
      describe("On Status Closed", () => {
        beforeEach(async () => {
          await commercialPaper.connect(accounts.registrarA).setLive();
          await commercialPaper
            .connect(accounts.registrarA)
            .mint(accounts.investorA, 1000);
          await commercialPaper.connect(accounts.registrarA).setClosed();
        });

        it("Should return 0 for all accounts but the issuer", async () => {
          expect(await commercialPaper.balanceOf(accounts.investorA)).to.equal(
            0
          );
        });

        it("Should return the totalSupply for the issuer", async () => {
          expect(await commercialPaper.balanceOf(accounts.issuerA)).to.equal(
            await commercialPaper.totalSupply()
          );
        });
      });

      it("Should return the account balance for each account", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();
        await commercialPaper
          .connect(accounts.registrarA)
          .mint(accounts.investorA, 1000);

        expect(await commercialPaper.balanceOf(accounts.investorA)).to.equal(
          1000
        );

        expect(await commercialPaper.balanceOf(accounts.issuerA)).to.equal(0);
      });
    });

    describe("transfer", () => {
      it("Should revert if is not in Live status", async () => {
        await expect(
          commercialPaper
            .connect(accounts.notARegistrar)
            .transfer(accounts.investorA, 1000)
        ).to.be.revertedWith(
          "transfers are not allowed when the contract is not live"
        );
      });

      it("Should revert if is global paused", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();
        await restrictions.connect(accounts.registrarA).pauseAll();

        await expect(
          commercialPaper
            .connect(accounts.notARegistrar)
            .transfer(accounts.investorA, 1000)
        ).to.be.revertedWith("Restrictions: All contracts are paused");
      });

      it("Should revert if contract is paused", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();
        await commercialPaper.connect(accounts.registrarA).pause();

        await expect(
          commercialPaper
            .connect(accounts.notARegistrar)
            .transfer(accounts.investorA, 1000)
        ).to.be.revertedWith("Pausable: paused");
      });

      it("Should revert if caller is not whitelisted", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await expect(
          commercialPaper
            .connect(accounts.notWhitelisted)
            .transfer(accounts.investorA, 1000)
        ).to.be.revertedWith("Your account is not whitelisted");
      });

      it("Should revert if recipient is not whitelisted", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await expect(
          commercialPaper
            .connect(accounts.investorA)
            .transfer(accounts.notWhitelisted, 1000)
        ).to.be.revertedWith("recipient is not whitelisted");
      });

      it("Should revert if amount is not multiple of minimumDenomination value", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await expect(
          commercialPaper
            .connect(accounts.investorA)
            .transfer(accounts.investorB, 7)
        ).to.be.revertedWith(
          "amount must be multiple of minimumDenomination value"
        );
      });

      it("Should revert if sender has insufficient balance", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await expect(
          commercialPaper
            .connect(accounts.investorA)
            .transfer(accounts.investorB, 1000)
        ).to.be.revertedWith("ERC20: transfer amount exceeds balance");
      });

      it("Should transfer 100 tokens to another account", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        // Mint 100 tokens
        await commercialPaper
          .connect(accounts.registrarA)
          .mint(accounts.investorA, 100);

        // Transfer 100 tokens
        await expect(
          commercialPaper
            .connect(accounts.investorA)
            .transfer(accounts.investorB, 100)
        ).to.changeTokenBalances(
          commercialPaper,
          [accounts.investorA, accounts.investorB],
          [-100, 100]
        );
      });

      it("Should emit a Transfer event if transfer is successful", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        // Mint 100 tokens
        await commercialPaper
          .connect(accounts.registrarA)
          .mint(accounts.investorA, 100);

        // Transfer 100 tokens
        await expect(
          commercialPaper
            .connect(accounts.investorA)
            .transfer(accounts.investorB, 100)
        ).to.emit(commercialPaper, "Transfer");
        // TODO: Add with Args
      });
    });

    describe("approve", () => {});

    describe("allowance", () => {});

    describe("burnAndMint", () => {
      it("Should revert if recipient is not whitelisted", async () => {
        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .burnAndMint(accounts.investorA, accounts.notWhitelisted, 1000)
        ).to.be.revertedWith("recipient is not whitelisted");
      });

      it("Should revert if original owner is not whitelisted", async () => {
        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .burnAndMint(accounts.notWhitelisted, accounts.investorB, 1000)
        ).to.be.revertedWith("Original holder is not whitelisted");
      });

      it("Should revert if caller is not registrar", async () => {
        await expect(
          commercialPaper
            .connect(accounts.notWhitelisted)
            .burnAndMint(accounts.investorA, accounts.issuerB, 1000)
        ).to.be.revertedWith("caller is not a registrar");
      });

      it("Should revert if insufficient balance", async () => {
        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .burnAndMint(accounts.investorA, accounts.investorB, 3000)
        ).to.be.revertedWith("ERC20: transfer amount exceeds balance");
      });

      it("Should revert if amount is not multiple of minimumDenomination value", async () => {
        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .burnAndMint(accounts.investorB, accounts.investorA, 7)
        ).to.be.revertedWith(
          "amount must be multiple of minimumDenomination value"
        );
      });

      it("Should emit a BurnAndMint event if burnAndMint is successful", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();
        // Mint 100 tokens
        await commercialPaper
          .connect(accounts.registrarA)
          .mint(accounts.investorA, 100);

        // Transfer 100 tokens
        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .burnAndMint(accounts.investorA, accounts.investorB, 100)
        ).to.emit(commercialPaper, "BurnAndMint"); // TODO: Add with Args
      });
      it("Should emit a BurnAndMint event if burnAndMint is successful", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();
        // Mint 100 tokens
        await commercialPaper
          .connect(accounts.registrarA)
          .mint(accounts.investorA, 100);

        // Transfer 100 tokens
        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .burnAndMint(accounts.investorA, accounts.investorB, 100)
        ).to.emit(commercialPaper, "BurnAndMint");
      });
    });

    // Business functions

    describe("mint", () => {
      it("Should revert if is not in Live status", async () => {
        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .mint(accounts.investorA, 1000)
        ).to.be.revertedWith(
          "minting is not allowed when the contract is not live"
        );
      });

      it("Should revert if is global paused", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();
        await restrictions.connect(accounts.registrarA).pauseAll();

        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .mint(accounts.investorA, 1000)
        ).to.be.revertedWith("Restrictions: All contracts are paused");
      });

      it("Should revert if contract is paused", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();
        await commercialPaper.connect(accounts.registrarA).pause();

        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .mint(accounts.investorA, 1000)
        ).to.be.revertedWith("Pausable: paused");
      });

      it("Should revert if recipient is not whitelisted", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .mint(accounts.notWhitelisted, 1000)
        ).to.be.revertedWith("Account is not whitelisted");
      });

      describe("Success Test Case - Called by Registrar", () => {
        beforeEach(async () => {
          await commercialPaper.connect(accounts.registrarA).setLive();
        });

        it("Should mint 100 tokens to another account", async () => {
          // Mint 100 tokens
          await expect(
            commercialPaper
              .connect(accounts.registrarA)
              .mint(accounts.investorA, 100)
          ).to.changeTokenBalance(commercialPaper, accounts.investorA, 100);
        });

        it("Should increase totalSupply when a mint is successful", async () => {
          // Mint 100 tokens
          await commercialPaper
            .connect(accounts.registrarA)
            .mint(accounts.investorA, 100);

          // Transfer 100 tokens
          expect(
            await commercialPaper.connect(accounts.registrarA).totalSupply()
          ).to.be.equal(100);
        });

        it("Should emit a Mint event if mint is successful", async () => {
          // Mint 100 tokens
          await expect(
            commercialPaper
              .connect(accounts.registrarA)
              .mint(accounts.investorB, 100)
          ).to.emit(commercialPaper, "Mint");
        });

        it("Should emit a Mint event if mint is successful", async () => {
          // Mint 100 tokens
          await expect(
            commercialPaper
              .connect(accounts.registrarA)
              .mint(accounts.investorB, 100)
          ).to.emit(commercialPaper, "Mint"); // TODO: Add with Args
        });
      });

      describe("Success Test Case - Called by Issuer", () => {
        beforeEach(async () => {
          await commercialPaper.connect(accounts.registrarA).setLive();
        });

        it("Should mint 100 tokens to another account", async () => {
          // Mint 100 tokens
          await expect(
            commercialPaper
              .connect(accounts.issuerA)
              .mint(accounts.investorA, 100)
          ).to.changeTokenBalance(commercialPaper, accounts.investorA, 100);
        });

        it("Should increase totalSupply when a mint is successful", async () => {
          // Mint 100 tokens
          await commercialPaper
            .connect(accounts.issuerA)
            .mint(accounts.investorA, 100);

          // Transfer 100 tokens
          expect(
            await commercialPaper.connect(accounts.issuerA).totalSupply()
          ).to.be.equal(100);
        });

        it("Should emit a Mint event if mint is successful", async () => {
          // Mint 100 tokens
          await expect(
            commercialPaper
              .connect(accounts.issuerA)
              .mint(accounts.investorB, 100)
          ).to.emit(commercialPaper, "Mint");
        });

        it("Should emit a Mint event if mint is successful", async () => {
          // Mint 100 tokens
          await expect(
            commercialPaper
              .connect(accounts.issuerA)
              .mint(accounts.investorB, 100)
          ).to.emit(commercialPaper, "Mint"); // TODO: Add with Args
        });
      });

      it("Should revert if caller isn't a registrar or whitelisted issuer", async () => {
        await expect(
          commercialPaper
            .connect(accounts.notARegistrar)
            .mint(accounts.investorA, 1000)
        ).to.be.revertedWith("caller is not an issuer or a registrar");
      });
    });

    describe("batchMint", () => {
      let accountsList: string[] = [];
      let amountsList: number[] = [];

      before(async () => {
        const numberOfMints = 923;

        for (let i = 0; i < numberOfMints; i++) {
          accountsList.push(ethers.Wallet.createRandom().address);
          amountsList.push(1);
        }
      });

      it("Should revert if caller isn't a registrar or whitelisted issuer", async () => {
        await expect(
          commercialPaper
            .connect(accounts.notARegistrar)
            .batchMint(accountsList, amountsList)
        ).to.be.revertedWith("caller is not an issuer or a registrar");
      });

      it("Should revert if is not in Live status", async () => {
        await restrictions
          .connect(accounts.registrarA)
          .addWhitelistAddress(accountsList);

        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .batchMint(accountsList, amountsList)
        ).to.be.revertedWith(
          "minting is not allowed when the contract is not live"
        );
      });

      it("Should revert if is global paused", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();
        await restrictions.connect(accounts.registrarA).pauseAll();

        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .batchMint(accountsList, amountsList)
        ).to.be.revertedWith("Restrictions: All contracts are paused");
      });

      it("Should revert if contract is paused", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();
        await commercialPaper.connect(accounts.registrarA).pause();

        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .batchMint(accountsList, amountsList)
        ).to.be.revertedWith("Pausable: paused");
      });

      it("Should revert if recipient is not whitelisted", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .batchMint(accountsList, amountsList)
        ).to.be.revertedWith("one or more addresses is not whitelisted");
      });

      it("Should revert if accounts and amounts list have different lenght", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await restrictions
          .connect(accounts.registrarA)
          .addWhitelistAddress(accountsList);

        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .batchMint(accountsList.slice(0, 5), amountsList.slice(0, 4))
        ).to.be.revertedWith("Input arrays must have the same length");
      });

      describe("Success Test Case - Called by Registrar", () => {
        beforeEach(async () => {
          await commercialPaper.connect(accounts.registrarA).setLive();
        });

        it("Should batch mint tokens to a list of accounts", async () => {
          await restrictions
            .connect(accounts.registrarA)
            .addWhitelistAddress(accountsList);

          await commercialPaper
            .connect(accounts.registrarA)
            .batchMint(accountsList, amountsList);

          accountsList.forEach(async (account) => {
            expect(await commercialPaper.balanceOf(account)).to.be.equal(1);
          });
        });

        it("Should increase number of tokens to every account when a batchMint is successful", async () => {
          await restrictions
            .connect(accounts.registrarA)
            .addWhitelistAddress(accountsList);

          await commercialPaper
            .connect(accounts.registrarA)
            .batchMint(accountsList, amountsList);

          accountsList.forEach(async (account) => {
            expect(
              await commercialPaper
                .connect(accounts.registrarA)
                .balanceOf(account)
            ).to.be.equal(1);
          });
        });

        it("Should emit a BatchMint event if mint is successful", async () => {
          await restrictions
            .connect(accounts.registrarA)
            .addWhitelistAddress(accountsList);

          await expect(
            commercialPaper
              .connect(accounts.registrarA)
              .batchMint(accountsList, amountsList)
          ).to.emit(commercialPaper, "BatchMint");
        });
      });

      describe("Success Test Case - Called by Issuer", () => {
        beforeEach(async () => {
          await commercialPaper.connect(accounts.registrarA).setLive();
        });

        it("Should batch mint tokens to a list of accounts", async () => {
          await restrictions
            .connect(accounts.registrarA)
            .addWhitelistAddress(accountsList);

          await commercialPaper
            .connect(accounts.issuerA)
            .batchMint(accountsList, amountsList);

          accountsList.forEach(async (account) => {
            expect(await commercialPaper.balanceOf(account)).to.be.equal(1);
          });
        });

        it("Should increase number of tokens to every account when a batchMint is successful", async () => {
          await restrictions
            .connect(accounts.registrarA)
            .addWhitelistAddress(accountsList);

          await commercialPaper
            .connect(accounts.registrarA)
            .batchMint(accountsList, amountsList);

          accountsList.forEach(async (account) => {
            expect(
              await commercialPaper
                .connect(accounts.registrarA)
                .balanceOf(account)
            ).to.be.equal(1);
          });
        });

        it("Should emit a BatchMint event if batchMint is successful", async () => {
          await restrictions
            .connect(accounts.registrarA)
            .addWhitelistAddress(accountsList);

          await expect(
            commercialPaper
              .connect(accounts.issuerA)
              .batchMint(accountsList, amountsList)
          ).to.emit(commercialPaper, "BatchMint");
        });
      });
    });

    describe("addIssuer", () => {
      describe("Success Test Case - Called by RegistrarA", () => {
        beforeEach(async () => {
          await commercialPaper
            .connect(accounts.registrarA)
            .addIssuer(accounts.issuerToBeAdded);
        });

        it("Should assign ISSUER role to the provided account", async () => {
          expect(
            await commercialPaper.hasRole(ISSUER_ROLE, accounts.issuerToBeAdded)
          ).to.be.true;
        });

        it("Should assign ISSUER_ADMIN role to the provided account", async () => {
          expect(
            await commercialPaper.hasRole(
              ISSUER_ADMIN_ROLE,
              accounts.issuerToBeAdded
            )
          ).to.be.true;
        });
      });

      describe("Success Test Case - Called by RegistrarB", () => {
        beforeEach(async () => {
          await commercialPaper
            .connect(accounts.registrarB)
            .addIssuer(accounts.issuerToBeAdded);
        });

        it("Should assign ISSUER role to the provided account", async () => {
          expect(
            await commercialPaper.hasRole(ISSUER_ROLE, accounts.issuerToBeAdded)
          ).to.be.true;
        });

        it("Should assign ISSUER_ADMIN role to the provided account", async () => {
          expect(
            await commercialPaper.hasRole(
              ISSUER_ADMIN_ROLE,
              accounts.issuerToBeAdded
            )
          ).to.be.true;
        });
      });

      describe("Success Test Case - Called by Issuer", () => {
        beforeEach(async () => {
          await commercialPaper
            .connect(accounts.registrarA)
            .addIssuer(accounts.issuerToBeAdded);
        });

        it("Should assign ISSUER role to the provided account", async () => {
          expect(
            await commercialPaper.hasRole(ISSUER_ROLE, accounts.issuerToBeAdded)
          ).to.be.true;
        });

        it("Should assign ISSUER_ADMIN role to the provided account", async () => {
          expect(
            await commercialPaper.hasRole(
              ISSUER_ADMIN_ROLE,
              accounts.issuerToBeAdded
            )
          ).to.be.true;
        });
      });

      it("Should revert if caller isn't a registrar account", async () => {
        await expect(
          commercialPaper
            .connect(accounts.notARegistrar)
            .addIssuer(accounts.issuerToBeAdded)
        ).to.be.revertedWith("caller is not an issuer or a registrar");
      });
    });

    describe("removeIssuer", () => {
      describe("Success Test Case - Called by RegistrarA", () => {
        beforeEach(async () => {
          await commercialPaper
            .connect(accounts.registrarA)
            .removeIssuer(accounts.issuerA);
        });

        it("Should remove ISSUER role from the provided account", async () => {
          expect(
            await commercialPaper.hasRole(ISSUER_ROLE, accounts.issuerA)
          ).to.be.false;
        });

        it("Should remove ISSUER_ADMIN role from the provided account", async () => {
          expect(
            await commercialPaper.hasRole(
              ISSUER_ADMIN_ROLE,
              accounts.issuerA
            )
          ).to.be.false;
        });
      });

      describe("Success Test Case - Called by RegistrarB", () => {
        beforeEach(async () => {
          await commercialPaper
            .connect(accounts.registrarB)
            .removeIssuer(accounts.issuerA);
        });

        it("Should remove ISSUER role from the provided account", async () => {
          expect(
            await commercialPaper.hasRole(ISSUER_ROLE, accounts.issuerA)
          ).to.be.false;
        });

        it("Should remove ISSUER_ADMIN role from the provided account", async () => {
          expect(
            await commercialPaper.hasRole(
              ISSUER_ADMIN_ROLE,
              accounts.issuerA
            )
          ).to.be.false;
        });
      });

      it("Should revert if caller isn't a registrar account", async () => {
        await expect(
          commercialPaper
            .connect(accounts.notARegistrar)
            .removeIssuer(accounts.issuerA)
        ).to.be.revertedWith("caller is not a registrar");
      });
    });

    // Getters

    describe("securityType", () => {
      it("Should return the CommercialPaper securityType", async () => {
        expect(await commercialPaper.securityType()).to.equal(
          0 // CommercialPaper
        );
      });
    });

    describe("isin", () => {
      it("Should return the CommercialPaper isin", async () => {
        expect(await commercialPaper.isin()).to.equal(commercialPaperArgs.isin);
      });
    });

    describe("currency", () => {
      it("Should return the CommercialPaper currency", async () => {
        expect(await commercialPaper.currency()).to.equal(
          commercialPaperArgs.currency
        );
      });
    });

    describe("maturity", () => {
      it("Should return the CommercialPaper maturity", async () => {
        expect(await commercialPaper.maturity()).to.equal(
          commercialPaperArgs.maturity
        );
      });
    });

    describe("minimumDenomination", () => {
      it("Should return the CommercialPaper minimumDenomination", async () => {
        expect(await commercialPaper.minimumDenomination()).to.equal(
          commercialPaperArgs.minimumDenomination
        );
      });
    });

    describe("addInfoURI", () => {
      it("Should return the CommercialPaper addInfoURI", async () => {
        expect(await commercialPaper.addInfoUri()).to.equal(
          commercialPaperArgs.addInfoUri
        );
      });
    });

    describe("checksum", () => {
      it("Should return the CommercialPaper checksum", async () => {
        expect(await commercialPaper.checksum()).to.equal(
          commercialPaperArgs.checksum
        );
      });
    });

    describe("cap", () => {
      it("Should return the CommercialPaper cap", async () => {
        expect(await commercialPaper.cap()).to.equal(commercialPaperArgs.cap);
      });
    });

    describe("restrictionsSmartContract", () => {
      it("Should return the CommercialPaper restrictionsSmartContract", async () => {
        expect(await commercialPaper.restrictionsSmartContract()).to.equal(
          commercialPaperArgs.restrictionsSmartContract
        );
      });
    });

    describe("status", () => {
      it("Should return the CommercialPaper status", async () => {
        expect(await commercialPaper.status()).to.equal(0);
      });
    });

    describe("paused", () => {
      it("Should return the CommercialPaper paused staus", async () => {
        expect(await commercialPaper.paused()).to.equal(false);
      });
    });

    describe("issuanceCountry", () => {
      it("Should return the CommercialPaper issuanceCountry", async () => {
        expect(await commercialPaper.issuanceCountry()).to.equal(
          commercialPaperArgs.issuanceCountry
        );
      });
    });

    describe("issuer", () => {
      it("Should return the CommercialPaper issuer", async () => {
        expect(await commercialPaper.issuer()).to.equal(
          commercialPaperArgs.issuer
        );
      });
    });

    // Setters

    describe("setISIN", () => {
      const newIsin = "NEW_CPP";

      describe("Success Test Case - Called By Registrar", () => {
        it("Should set a new isin if contract is in Preliminary status", async () => {
          await commercialPaper.connect(accounts.registrarA).setISIN(newIsin);

          expect(await commercialPaper.isin()).to.be.equal(newIsin);
        });
      });

      it("Should revert if is not in Preliminary status", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await expect(
          commercialPaper.connect(accounts.registrarA).setISIN(newIsin)
        ).to.be.revertedWith("contract is not in Preliminary status");
      });

      it("Should revert if caller isn't a registrar or whitelisted issuer", async () => {
        await expect(
          commercialPaper.connect(accounts.notARegistrar).setISIN(newIsin)
        ).to.be.revertedWith("caller is not a registrar");
      });
    });

    describe("setChecksum", () => {
      const newChecksum =
        "C5276137BF22F3CF987ECDBCE9D10F573C65EE9684D94FCDE2CDBCCE9E3D20BA";

      describe("Success Test Case - Called By Registrar", () => {
        it("Should set a new checksum if contract is in Preliminary status", async () => {
          await commercialPaper
            .connect(accounts.registrarA)
            .setChecksum(newChecksum);

          expect(await commercialPaper.checksum()).to.be.equal(newChecksum);
        });
      });

      it("Should revert if is not in Preliminary status", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await expect(
          commercialPaper.connect(accounts.registrarA).setChecksum(newChecksum)
        ).to.be.revertedWith("contract is not in Preliminary status");
      });

      it("Should revert if caller is not an issuer or a registrar ", async () => {
        await expect(
          commercialPaper
            .connect(accounts.notARegistrar)
            .setChecksum(newChecksum)
        ).to.be.revertedWith("caller is not a registrar");
      });
    });

    describe("setSecurityType", () => {
      const newSecurityType = 1; // Bond

      describe("Success Test Case - Called By Registrar", () => {
        it("Should set a new security type if contract is in Preliminary status", async () => {
          await commercialPaper
            .connect(accounts.registrarA)
            .setSecurityType(newSecurityType);

          expect(await commercialPaper.securityType()).to.be.equal(
            newSecurityType
          );
        });
      });

      it("Should revert if is not in Preliminary status", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .setSecurityType(newSecurityType)
        ).to.be.revertedWith("contract is not in Preliminary status");
      });

      it("Should revert if caller is not an issuer or a registrar", async () => {
        await expect(
          commercialPaper
            .connect(accounts.notARegistrar)
            .setSecurityType(newSecurityType)
        ).to.be.revertedWith("caller is not a registrar");
      });
    });

    describe("setMaturity", () => {
      const newMaturity = "2025-10-01T21:00:00.000Z";

      describe("Success Test Case - Called By Registrar", () => {
        it("Should set a new maturity if contract is in Preliminary status", async () => {
          await commercialPaper
            .connect(accounts.registrarA)
            .setMaturity(newMaturity);

          expect(await commercialPaper.maturity()).to.be.equal(newMaturity);
        });
      });

      it("Should revert if is not in Preliminary status", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await expect(
          commercialPaper.connect(accounts.registrarA).setMaturity(newMaturity)
        ).to.be.revertedWith("contract is not in Preliminary status");
      });

      it("Should revert if caller is not a registrar ", async () => {
        await expect(
          commercialPaper
            .connect(accounts.notARegistrar)
            .setMaturity(newMaturity)
        ).to.be.revertedWith("caller is not a registrar");
      });
    });

    describe("setMinimumDenomination", () => {
      const newMinimumDenomination = 2000;

      describe("Success Test Case - Called By Registrar", () => {
        it("Should set a new minimumDenomination if contract is in Preliminary status", async () => {
          await commercialPaper
            .connect(accounts.registrarA)
            .setMinimumDenomination(newMinimumDenomination);

          expect(await commercialPaper.minimumDenomination()).to.be.equal(
            newMinimumDenomination
          );
        });
      });

      it("Should revert if is not in Preliminary status", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .setMinimumDenomination(newMinimumDenomination)
        ).to.be.revertedWith("contract is not in Preliminary status");
      });

      it("Should revert if caller isn't a registrar or whitelisted issuer", async () => {
        await expect(
          commercialPaper
            .connect(accounts.notARegistrar)
            .setMinimumDenomination(newMinimumDenomination)
        ).to.be.revertedWith("caller is not a registrar");
      });
    });

    describe("setIssuer", () => {
      describe("Success Test Case - Called By Registrar", () => {
        it("Should set a new issuer if contract is in Preliminary status", async () => {
          await commercialPaper
            .connect(accounts.registrarA)
            .setIssuer(accounts.issuerB);

          expect(await commercialPaper.issuer()).to.be.equal(
            accounts.issuerB.address
          );
        });
      });

      it("Should revert if is not in Preliminary status", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .setIssuer(accounts.issuerB)
        ).to.be.revertedWith("contract is not in Preliminary status");
      });

      it("Should revert if caller isn't a registrar or whitelisted issuer", async () => {
        await expect(
          commercialPaper
            .connect(accounts.notARegistrar)
            .setIssuer(accounts.issuerB)
        ).to.be.revertedWith("caller is not a registrar");
      });
    });

    describe("setAddInfoUri", () => {
      const newaddInfoUri = "https://example.com/newInfoURI";

      describe("Success Test Case - Called By Registrar", () => {
        it("Should set a new addInfoUri if contract is in Preliminary status", async () => {
          await commercialPaper
            .connect(accounts.registrarA)
            .setAddInfoUri(newaddInfoUri);

          expect(await commercialPaper.addInfoUri()).to.be.equal(newaddInfoUri);
        });
      });

      it("Should revert if is not in Preliminary status", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .setAddInfoUri(newaddInfoUri)
        ).to.be.revertedWith("contract is not in Preliminary status");
      });

      it("Should revert if caller isn't a registrar or whitelisted issuer", async () => {
        await expect(
          commercialPaper
            .connect(accounts.notARegistrar)
            .setAddInfoUri(newaddInfoUri)
        ).to.be.revertedWith("caller is not a registrar");
      });
    });

    describe("setIssuanceCountry", () => {
      const newIssuanceCountry = "Spain";

      describe("Success Test Case - Called By Registrar", () => {
        it("Should set a new issuance country if contract is in Preliminary status", async () => {
          await commercialPaper
            .connect(accounts.registrarA)
            .setIssuanceCountry(newIssuanceCountry);

          expect(await commercialPaper.issuanceCountry()).to.be.equal(
            newIssuanceCountry
          );
        });
      });

      it("Should revert if is not in Preliminary status", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await expect(
          commercialPaper
            .connect(accounts.registrarA)
            .setIssuanceCountry(newIssuanceCountry)
        ).to.be.revertedWith("contract is not in Preliminary status");
      });

      it("Should revert if caller isn't a registrar or whitelisted issuer", async () => {
        await expect(
          commercialPaper
            .connect(accounts.notARegistrar)
            .setIssuanceCountry(newIssuanceCountry)
        ).to.be.revertedWith("caller is not a registrar");
      });
    });

    describe("setCurrency", () => {
      const newCurrency = "USD";

      describe("Success Test Case - Called By Registrar", () => {
        it("Should set a new currency if contract is in Preliminary status", async () => {
          await commercialPaper
            .connect(accounts.registrarA)
            .setCurrency(newCurrency);

          expect(await commercialPaper.currency()).to.be.equal(newCurrency);
        });
      });

      it("Should revert if is not in Preliminary status", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await expect(
          commercialPaper.connect(accounts.registrarA).setCurrency(newCurrency)
        ).to.be.revertedWith("contract is not in Preliminary status");
      });

      it("Should revert if caller isn't a registrar or whitelisted issuer", async () => {
        await expect(
          commercialPaper
            .connect(accounts.notARegistrar)
            .setCurrency(newCurrency)
        ).to.be.revertedWith("caller is not a registrar");
      });
    });

    describe("setName", () => {
      const newName = "New CommercialPaper name";

      describe("Success Test Case - Called By Registrar", () => {
        it("Should set a new name if contract is in Preliminary status", async () => {
          await commercialPaper.connect(accounts.registrarA).setName(newName);

          expect(await commercialPaper.name()).to.be.equal(newName);
        });
      });

      it("Should revert if is not in Preliminary status", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await expect(
          commercialPaper.connect(accounts.registrarA).setName(newName)
        ).to.be.revertedWith("contract is not in Preliminary status");
      });

      it("Should revert if caller isn't a registrar or whitelisted issuer", async () => {
        await expect(
          commercialPaper.connect(accounts.notARegistrar).setName(newName)
        ).to.be.revertedWith("caller is not a registrar");
      });
    });

    describe("setSymbol", () => {
      const newSymbol = "NCPP";

      describe("Success Test Case - Called By Registrar", () => {
        it("Should set a new symbol if contract is in Preliminary status", async () => {
          await commercialPaper
            .connect(accounts.registrarA)
            .setSymbol(newSymbol);

          expect(await commercialPaper.symbol()).to.be.equal(newSymbol);
        });
      });

      it("Should revert if is not in Preliminary status", async () => {
        await commercialPaper.connect(accounts.registrarA).setLive();

        await expect(
          commercialPaper.connect(accounts.registrarA).setSymbol(newSymbol)
        ).to.be.revertedWith("contract is not in Preliminary status");
      });

      it("Should revert if caller isn't a registrar or whitelisted issuer", async () => {
        await expect(
          commercialPaper.connect(accounts.notARegistrar).setSymbol(newSymbol)
        ).to.be.revertedWith("caller is not a registrar");
      });
    });

    // Pause

    describe("pause", () => {
      describe("Success Test Case - Called By Registrar", () => {
        it("Should set CommercialPaper paused", async () => {
          await commercialPaper.connect(accounts.registrarA).pause();
          expect(await commercialPaper.paused()).to.be.equal(true);
        });

        it("Should emit a Pause event", async () => {
          await expect(
            commercialPaper.connect(accounts.registrarA).pause()
          ).to.emit(commercialPaper, "Paused");
        });
      });

      it("Should revert if caller is an issuer", async () => {
        await expect(
          commercialPaper.connect(accounts.issuerA).pause()
        ).to.be.revertedWith("caller is not a registrar");
      });

      it("Should revert if caller is not a registrar", async () => {
        await expect(
          commercialPaper.connect(accounts.notARegistrar).pause()
        ).to.be.revertedWith("caller is not a registrar");
      });
    });

    describe("unpause", () => {
      describe("Success Test Case - Called By Registrar", () => {
        it("Should set CommercialPaper unpaused", async () => {
          await commercialPaper.connect(accounts.registrarA).pause();
          await commercialPaper.connect(accounts.registrarA).unpause();

          expect(await commercialPaper.paused()).to.be.equal(false);
        });

        it("Should emit a Unpause event", async () => {
          await commercialPaper.connect(accounts.registrarA).pause();
          await expect(
            commercialPaper.connect(accounts.registrarA).unpause()
          ).to.emit(commercialPaper, "Unpaused");
        });
      });

      it("Should revert if caller is not a registrar", async () => {
        await expect(
          commercialPaper.connect(accounts.notARegistrar).pause()
        ).to.be.revertedWith("caller is not a registrar");
      });

      it("Should revert if caller is an issuer", async () => {
        await expect(
          commercialPaper.connect(accounts.issuerA).pause()
        ).to.be.revertedWith("caller is not a registrar");
      });
    });

    // Change status

    describe("setLive", () => {
      describe("Success Test Case - Called By Registrar", () => {
        it("Should set CommercialPaper status to Live", async () => {
          await commercialPaper.connect(accounts.registrarA).setLive();
          expect(await commercialPaper.status()).to.be.equal(1);
        });

        it("Should emit a ChangeStatus event", async () => {
          const oldStatus = await commercialPaper.status();
          await expect(commercialPaper.connect(accounts.registrarA).setLive())
            .to.emit(commercialPaper, "ChangeStatus")
            .withArgs(oldStatus, 1);
        });
      });

      describe("Success Test Case - Called By Registrar", () => {
        it("Should set CommercialPaper status to Live", async () => {
          await commercialPaper.connect(accounts.registrarA).setLive();
          expect(await commercialPaper.status()).to.be.equal(1);
        });

        it("Should emit a ChangeStatus event", async () => {
          const oldStatus = await commercialPaper.status();
          await expect(commercialPaper.connect(accounts.registrarA).setLive())
            .to.emit(commercialPaper, "ChangeStatus")
            .withArgs(oldStatus, 1);
        });
      });

      it("Should revert if caller is not a registrar", async () => {
        await expect(
          commercialPaper.connect(accounts.notARegistrar).setLive()
        ).to.be.revertedWith("caller is not a registrar");
      });
    });

    describe("setMatured", () => {
      describe("Success Test Case - Called By Registrar", () => {
        it("Should set CommercialPaper status to Matured", async () => {
          await commercialPaper.connect(accounts.registrarA).setMatured();
          expect(await commercialPaper.status()).to.be.equal(2);
        });

        it("Should emit a ChangeStatus event", async () => {
          const oldStatus = await commercialPaper.status();
          await expect(
            commercialPaper.connect(accounts.registrarA).setMatured()
          )
            .to.emit(commercialPaper, "ChangeStatus")
            .withArgs(oldStatus, 2);
        });
      });

      it("Should revert if caller is not a registrar", async () => {
        await expect(
          commercialPaper.connect(accounts.notARegistrar).setMatured()
        ).to.be.revertedWith("caller is not a registrar");
      });
    });

    describe("setClosed", () => {
      describe("Success Test Case - Called By Registrar", () => {
        it("Should set CommercialPaper status to Closed", async () => {
          await commercialPaper.connect(accounts.registrarA).setClosed();
          expect(await commercialPaper.status()).to.be.equal(3);
        });

        it("Should emit a ChangeStatus event", async () => {
          const oldStatus = await commercialPaper.status();
          await expect(commercialPaper.connect(accounts.registrarA).setClosed())
            .to.emit(commercialPaper, "ChangeStatus")
            .withArgs(oldStatus, 3);
        });
      });

      it("Should revert if caller is not a registrar", async () => {
        await expect(
          commercialPaper.connect(accounts.notARegistrar).setClosed()
        ).to.be.revertedWith("caller is not a registrar");
      });
    });
  });
});
