import { loadFixture } from "@nomicfoundation/hardhat-toolbox/network-helpers";

import { expect } from "chai";
import { ethers } from "hardhat";

import { CommercialPaper } from "../typechain-types/contracts/CommercialPaper";
import { HLC } from "../typechain-types/contracts/HLC";
import { Restrictions } from "../typechain-types/contracts/Restrictions";

import { CommercialPaperArgs, HlcAccounts } from "./types";

var sha256 = require("js-sha256").sha256; // TODO: Remove this dependency and use from ethers

// utils
// const { expectEvent, singletons, constants } = require("@openzeppelin/test-helpers");
// const mineTx = require("./utils/mineTx");
// const { ZERO_ADDRESS } = constants;

// keys
const CANCELLATION_KEY = "Canc key";
const EXECUTION_KEY = "Exec key";

// amount_token
const AMOUNT_TOKEN = 1;

// states
const STATE_EXECUTED = 1;
const STATE_CANCELLED = 2;

// hlc info
const HLC_PRICE = "99.99";
const HLC_TIPS = ethers.toUtf8Bytes("TIPS_ID");

describe("HLC", () => {
  async function deployHLCFixture() {
    const HLC = await ethers.getContractFactory("HLC");
    const CommercialPaper = await ethers.getContractFactory("CommercialPaper");
    const Restrictions = await ethers.getContractFactory("Restrictions");

    const signers = await ethers.getSigners();

    const accounts: HlcAccounts = {
      deployer: signers[0],
      seller: signers[1],
      buyer: signers[2],
    };

    const restrictionsIntance = await Restrictions.connect(
      accounts.deployer
    ).deploy();

    const commercialPaperArgs: CommercialPaperArgs = {
      isLive: true,
      name: "CommercialPaper",
      symbol: "CPP",
      isin: "CPP",
      issuanceCountry: "Germany",
      currency: "EUR",
      maturity: "2024-08-10T18:00:00.000Z",
      minimumDenomination: 1,
      addInfoUri: "https://example.com/addInfoURI",
      checksum:
        "F70460D4D381FCC8DFD30DEF44993BD4952E3EB71E50CA4372D77F274AE1CBF2",
      cap: 1000,
      restrictionsSmartContract: await restrictionsIntance.getAddress(),
      issuer: accounts.deployer.address,
    };

    const tokenInstance = await CommercialPaper.connect(
      accounts.deployer
    ).deploy(
      commercialPaperArgs.isLive,
      commercialPaperArgs.name,
      commercialPaperArgs.symbol,
      commercialPaperArgs.isin,
      commercialPaperArgs.issuanceCountry,
      commercialPaperArgs.currency,
      commercialPaperArgs.maturity,
      commercialPaperArgs.minimumDenomination,
      commercialPaperArgs.addInfoUri,
      commercialPaperArgs.checksum,
      commercialPaperArgs.cap,
      commercialPaperArgs.restrictionsSmartContract,
      commercialPaperArgs.issuer
    );

    await restrictionsIntance
      .connect(accounts.deployer)
      .addWhitelistAddress([accounts.seller, accounts.buyer]);

    await tokenInstance
      .connect(accounts.deployer)
      .mint(accounts.seller, AMOUNT_TOKEN);

    const hlcInstance = await HLC.deploy(
      accounts.seller,
      accounts.buyer,
      HLC_PRICE, // <-- price
      AMOUNT_TOKEN, // <-- token_amount
      HLC_TIPS, // <-- tips
      "0x" + sha256(EXECUTION_KEY),
      "0x" + sha256(CANCELLATION_KEY),
      await tokenInstance.getAddress()
    );

    await restrictionsIntance
      .connect(accounts.deployer)
      .addWhitelistAddress([await hlcInstance.getAddress()]);

    return { accounts, hlcInstance, tokenInstance, restrictionsIntance };
  }

  let hlcInstance: HLC;
  let tokenInstance: CommercialPaper;
  let restrictionsIntance: Restrictions;
  let accounts: HlcAccounts;

  beforeEach(async () => {
    const fixture = await loadFixture(deployHLCFixture);

    accounts = fixture.accounts;
    hlcInstance = fixture.hlcInstance;
    tokenInstance = fixture.tokenInstance;
    restrictionsIntance = fixture.restrictionsIntance;

    // balance before transfer
    let _balanceDeployer = await tokenInstance.balanceOf(accounts.deployer);
    let _balanceSeller = await tokenInstance.balanceOf(accounts.seller);

    expect(_balanceDeployer).to.be.equal(0); // Deployer should have 0 token in its balance after transfer
    expect(_balanceSeller).to.be.greaterThanOrEqual(AMOUNT_TOKEN); // Seller should have AMOUNT_TOKEN token in its balance after transfer
  });

  it("Cooperative Cancellation", async function () {
    // transfer token to the seller
    await tokenInstance
      .connect(accounts.seller)
      .transfer(hlcInstance.getAddress(), AMOUNT_TOKEN);

    let _balanceHlc = await tokenInstance.balanceOf(hlcInstance.getAddress());

    //console.log("balance HLC ", balanceHlc);

    expect(_balanceHlc).to.be.equal(AMOUNT_TOKEN); // Hlc contract should have AMOUNT_TOKEN token in its balance

    // cooperative cancellation
    let _trx = await hlcInstance
      .connect(accounts.buyer)
      .cooperativeCancellation();

    let _state = await hlcInstance.hlcStatus();

    expect(_state).to.be.equal(STATE_CANCELLED); // Hlc state should be 'Cancelled'"

    //console.log("trx cooperative cancellation", trx);
  });

  it("Cooperative Cancellation when HLC contract is not whitelisted", async function () {
    // transfer token to the seller
    await tokenInstance
      .connect(accounts.seller)
      .transfer(hlcInstance.getAddress(), AMOUNT_TOKEN);

    await restrictionsIntance
      .connect(accounts.deployer)
      .removeWhitelistAddress([await hlcInstance.getAddress()]);

    await expect(
      hlcInstance.connect(accounts.buyer).cooperativeCancellation()
    ).to.be.revertedWith("Your account is not whitelisted");
  });

  it("Cooperative Cancellation without transfer to HLC beforehand", async function () {
    await expect(
      hlcInstance.connect(accounts.buyer).cooperativeCancellation()
    ).to.be.revertedWith("ERC20: transfer amount exceeds balance");
  });

  it("Cooperative Execution", async function () {
    // transfer token to the seller
    await tokenInstance
      .connect(accounts.seller)
      .transfer(hlcInstance.getAddress(), AMOUNT_TOKEN);

    let _balanceHlc = await tokenInstance.balanceOf(hlcInstance.getAddress());

    expect(_balanceHlc).to.be.equal(AMOUNT_TOKEN); // Hlc contract should have AMOUNT_TOKEN token in its balance

    // cooperative execution
    let _trx = await hlcInstance
      .connect(accounts.seller)
      .cooperativeExecution();

    let _state = await hlcInstance.hlcStatus();

    expect(_state).to.be.equal(STATE_EXECUTED); // Hlc state should be 'Executed'")

    //console.log("trx cooperative execution", trx);
  });

  it("Cooperative Execution when HLC contract is not whitelisted", async function () {
    // transfer token to the seller
    await tokenInstance
      .connect(accounts.seller)
      .transfer(hlcInstance.getAddress(), AMOUNT_TOKEN);

    await restrictionsIntance
      .connect(accounts.deployer)
      .removeWhitelistAddress([await hlcInstance.getAddress()]);

    await expect(
      hlcInstance.connect(accounts.seller).cooperativeExecution()
    ).to.be.revertedWith("Your account is not whitelisted");
  });

  it("Cooperative Execution without transfer to HLC beforehand", async function () {
    await expect(
      hlcInstance.connect(accounts.seller).cooperativeExecution()
    ).to.be.revertedWith("ERC20: transfer amount exceeds balance");
  });

  it("Forced Cancellation", async function () {
    // transfer token to the seller
    await tokenInstance
      .connect(accounts.seller)
      .transfer(hlcInstance.getAddress(), AMOUNT_TOKEN);

    let _balanceHlc = await tokenInstance.balanceOf(hlcInstance.getAddress());

    //console.log("balance HLC ", balanceHlc);

    expect(_balanceHlc).to.be.equal(AMOUNT_TOKEN); // Hlc contract should have AMOUNT_TOKEN token in its balance

    // force cancellation
    let _trx = await hlcInstance
      .connect(accounts.seller)
      .forceCancellation(CANCELLATION_KEY);

    let _state = await hlcInstance.hlcStatus();

    expect(_state).to.be.equal(STATE_CANCELLED); // Hlc state should be 'Cancelled'")

    //console.log("trx forced cancellation", trx);
  });

  it("Forced Cancellation when HLC contract is not whitelisted", async function () {
    // transfer token to the seller
    await tokenInstance
      .connect(accounts.seller)
      .transfer(hlcInstance.getAddress(), AMOUNT_TOKEN);

    await restrictionsIntance
      .connect(accounts.deployer)
      .removeWhitelistAddress([await hlcInstance.getAddress()]);

    await expect(
      hlcInstance.connect(accounts.seller).forceCancellation(CANCELLATION_KEY)
    ).to.be.revertedWith("Your account is not whitelisted");
  });

  it("Forced Cancellation without transfer to HLC beforehand", async function () {
    await expect(
      hlcInstance.connect(accounts.seller).forceCancellation(CANCELLATION_KEY)
    ).to.be.revertedWith("ERC20: transfer amount exceeds balance");
  });

  it("Forced Cancellation with wrong cancellation key", async function () {
    // force cancellation
    await expect(
      hlcInstance
        .connect(accounts.seller)
        .forceCancellation("WRONG_CANCELLATION_KEY")
    ).to.be.revertedWith("HLC: hash cancellation Key is not valid");
  });

  it("Forced Execution", async function () {
    // transfer token to the seller
    await tokenInstance
      .connect(accounts.seller)
      .transfer(hlcInstance.getAddress(), AMOUNT_TOKEN);

    let _balanceHlc = await tokenInstance.balanceOf(hlcInstance.getAddress());

    //console.log("balance HLC ", balanceHlc);

    expect(_balanceHlc).to.be.equal(AMOUNT_TOKEN); // Hlc contract should have AMOUNT_TOKEN token in its balance

    // force execution
    let _trx = await hlcInstance
      .connect(accounts.buyer)
      .forceExecution(EXECUTION_KEY);

    let _state = await hlcInstance.hlcStatus();

    expect(_state).to.be.equal(STATE_EXECUTED); // Hlc state should be 'Executed'")

    //console.log("trx forced execution", trx);
  });

  it("Forced Execution when HLC contract is not whitelisted", async function () {
    // transfer token to the seller
    await tokenInstance
      .connect(accounts.seller)
      .transfer(hlcInstance.getAddress(), AMOUNT_TOKEN);

    await restrictionsIntance
      .connect(accounts.deployer)
      .removeWhitelistAddress([await hlcInstance.getAddress()]);

    await expect(
      hlcInstance.connect(accounts.buyer).forceExecution(EXECUTION_KEY)
    ).to.be.revertedWith("Your account is not whitelisted");
  });

  it("Forced Execution without transfer to HLC beforehand", async function () {
    await expect(
      hlcInstance.connect(accounts.buyer).forceExecution(EXECUTION_KEY)
    ).to.be.revertedWith("ERC20: transfer amount exceeds balance");
  });

  it("Forced Execution with wrong execution key", async function () {
    // force cancellation
    await expect(
      hlcInstance.connect(accounts.buyer).forceExecution("WRONG_EXECUTION_KEY")
    ).to.be.revertedWith("HLC: hashexecutionKey is not valid");
  });
});
