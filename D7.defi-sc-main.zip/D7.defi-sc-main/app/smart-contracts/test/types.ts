import { HardhatEthersSigner } from "@nomicfoundation/hardhat-ethers/signers";

export type CommercialPaperAccounts = {
  registrarA: HardhatEthersSigner;
  registrarB: HardhatEthersSigner;
  issuerA: HardhatEthersSigner;
  issuerB: HardhatEthersSigner;
  notARegistrar: HardhatEthersSigner;
  notAnIssuer: HardhatEthersSigner;
  notWhitelisted: HardhatEthersSigner;
  investorA: HardhatEthersSigner;
  investorB: HardhatEthersSigner;
  issuerToBeAdded: HardhatEthersSigner;
};

export type RestrictionsAccounts = {
  registrar: HardhatEthersSigner;
  issuer: HardhatEthersSigner;
  notARegistrar: HardhatEthersSigner;
  registrarToBeAdded: HardhatEthersSigner;
  issuerToBeAdded: HardhatEthersSigner;
  whitelistToBeAddedA: HardhatEthersSigner;
  whitelistToBeAddedB: HardhatEthersSigner;
  whitelistToBeAddedC: HardhatEthersSigner;
  investorA: HardhatEthersSigner;
  investorB: HardhatEthersSigner;
  investorC: HardhatEthersSigner;
};

export type HlcAccounts = {
  deployer: HardhatEthersSigner;
  seller: HardhatEthersSigner;
  buyer: HardhatEthersSigner;
};

export type CommercialPaperArgs = {
  isLive: boolean;
  name: string;
  symbol: string;
  isin: string;
  issuanceCountry: string;
  currency: string;
  maturity: string;
  minimumDenomination: number;
  addInfoUri: string;
  checksum: string;
  cap: number;
  restrictionsSmartContract: string;
  issuer: string;
};

export type HlcArgs = {
  securityType: number;
  isLive: boolean;
  name: string;
  symbol: string;
  isin: string;
  issuanceCountry: string;
  currency: string;
  maturity: string;
  minimumDenomination: number;
  addInfoUri: string;
  checksum: string;
  cap: number;
  restrictionsSmartContract: string;
  issuer: string;
};
