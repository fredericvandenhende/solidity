# Hardhat Project

This is a smart contract project using Hardhat, which is a development environment to compile, deploy, test, and debug your Ethereum software.

This project includes tests, scripts, and smart contract files written in Solidity.

## Prerequisites

Before starting, make sure you have the following installed:

- Node.js (version 18 or higher)
- npm (comes with Node.js)

## Install dependencies

```bash
npm install
```

## Compile

Compile the smart contracts with Hardhat:

```bash
npx hardhat compile
```

## Test

Run the Mocha tests:

```bash
npx hardhat test
```

## Deploy

Deploy the contracts to the Hardhat Network:

```bash
npx hardhat run scripts/deploy.js
```

## Configuration

Configuration can be set in the `hardhat.config.js` file, including the network and compiler settings.