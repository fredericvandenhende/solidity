import { HardhatUserConfig } from "hardhat/config";
import "@nomicfoundation/hardhat-toolbox";
import "@nomiclabs/hardhat-solhint";

require("dotenv").config();


const config: HardhatUserConfig = {
  solidity: {
    version: "0.8.19",
    settings: {
      viaIR: true,
      optimizer: {
        // Disabled by default.
        // NOTE: enabled=false still leaves some optimizations on. See comments below.
        // WARNING: Before version 0.8.6 omitting the 'enabled' key was not equivalent to setting
        // it to false and would actually disable all the optimizations.
        enabled: true,
        // Optimize for how many times you intend to run the code.
        // Lower values will optimize more for initial deployment cost, higher
        // values will optimize more for high-frequency usage.
        runs: 200,
        // Switch optimizer components on or off in detail.
        // The "enabled" switch above provides two defaults which can be
        // tweaked here. If "details" is given, "enabled" can be omitted.
        details: {
          // The new Yul optimizer. Mostly operates on the code of ABI coder v2
          // and inline assembly.
          // It is activated together with the global optimizer setting
          // and can be deactivated here.
          // Before Solidity 0.6.0 it had to be activated through this switch.
          yul: true,
          // Tuning options for the Yul optimizer.
          yulDetails: {
            // Select optimization steps to be applied. It is also possible to modify both the
            // optimization sequence and the clean-up sequence. Instructions for each sequence
            // are separated with the ":" delimiter and the values are provided in the form of
            // optimization-sequence:clean-up-sequence. For more information see
            // "The Optimizer > Selecting Optimizations".
            // This field is optional, and if not provided, the default sequences for both
            // optimization and clean-up are used. If only one of the sequences is provided
            // the other will not be run.
            // If only the delimiter ":" is provided then neither the optimization nor the clean-up
            // sequence will be run.
            // If set to an empty value, only the default clean-up sequence is used and
            // no optimization steps are applied.
            optimizerSteps: "u",
          },
        },
      },
    },
  },
  networks: {
    mumbai: {
      url: `https://rpc-mumbai.maticvigil.com`,
      accounts: [process.env.REGISTRAR_PRIV_KEY! || "2666d455dab2b17d1ce385c70ac5d0009776df561d30a7a4d9e088faf2a03654"],
    },
  },
  etherscan: {
    apiKey: {
      polygonMumbai: process.env.POLYGONSCAN_APY_KEY! || "",
    },
  },
};

export default config;
