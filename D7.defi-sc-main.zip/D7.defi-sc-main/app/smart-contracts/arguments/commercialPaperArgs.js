module.exports = [
  true,
  "Digital Security 1",
  "DE1234ABCD56",
  "DE1234ABCD56",
  "Germany",
  "EUR",
  "31/12/2023",
  1000,
  "https://example.com/securityUri",
  "F70460D4D381FCC8DFD30DEF44993BD4952E3EB71E50CA4372D77F274AE1CBF2",
  100000,
  "0xaB8e3dcF66610B333681973308Bf50540AFa1418", // restriction.Address
  "0x340E8f37404eA609eab57147de4124FD86C7b9e3",
];
