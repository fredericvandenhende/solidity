module.exports = [
  "0x340E8f37404eA609eab57147de4124FD86C7b9e3",
  "0x66CF29c7076b5A340cd79582EaF06981843D82Eb",
  99, // <-- price
  1000, // <-- token_amount
  "0x544950535f4944", // <-- tips
  "0x13267c54f5e0b263a77f41deeeca8afeae4f05192d337ba0e143e15bae4aeb35",
  "0xd4c18066eed739b0923f29b500b083bd8bb941704bc79501890a574588f3191b",
  "0xFf7DAf779D69b04D2623a6Ed0c8CF54a16e1c1c4", // commercialPaper.getAddress
];
