## I. Project description
The microservice is a read-only crypto bridge to monitor the on-chain components of the crypto<br>
security register. The service tracks the on-chain activity of the registrar account, all digital<br>
instruments and auxiliary contracts (security accounts, whitelist account and HLC account), and<br>
triggers respective updates of the off-chain components and the DI API through BPO.

## II. Project dependencies
    Java 17
    SpringBoot 2.7.6
    Kafka Client 3.1.0
    Confluent Plugins 7.1.0

## III. Setting up the technologies in order to run service locally:
- [Podman](https://linux.how2shout.com/how-to-install-podman-on-ubuntu-20-04-lts-focal-fossa/)
- Podman-compose <br/>
  ```sudo apt install python3-pip```<br/>
  ```pip3 install https://github.com/containers/podman-compose/archive/devel.tar.gz``` <br/>
  (if you are not able to download it with terminal, you could use the browser and unpack it locally)

## IV. How to start the application in container locally
```sudo mvn clean install```<br/>
In terminal open the 'app/bc-event-etl/' folder where Dockerfile is located<br/>
```sudo podman build .``` The image from Dockerfile is build <br/>
```sudo podman network create -d bridge kafka_network``` the network name should be the same as in docker-compose.yml<br/>
```sudo podman run --network=kafka_network IMAGE_ID``` - the app is run in container <br/>
```sudo podman stop IMAGE_ID``` - the container is stopped <br/>

## V. How to start Kafka in container locally
Before running kafka, make sure that the network is created or create it with the command<br/>
```sudo podman network create -d bridge kafka_network``` the network name should be the same as in docker-compose.yml<br/>
```sudo python3 /FOLDER_WHERE_PODMAN__COMPOSED_INSTALLED/podman_compose.py up -d``` <br/>
Kafka components from 'docker-compose.yml' will start in a podman container <br/>
```sudo podman ps``` - You will see the container list <br/>
```sudo python3 /FOLDER_WHERE_PODMAN__COMPOSED_INSTALLED/podman_compose.py down``` - All containers are stopped

## VI. How to start bucket emulation locally
1. Start the emulation locally <br/>
```sudo podman run -d --name fake-gcs-server -p 9023:4443 -v PATH_TO_FAKE_BUCKET:/data fsouza/fake-gcs-server -scheme http```
2. Set the environment variable (or use it during running jar)<br/>
```-Dspring.profiles.active=local``` <br/>
It will make the application use application-local.properties instead of application.properties<br/>
3. When running tests locally, you should set environment configuration "spring.profiles.active=local" in run configurations<br/>
<p/>Now you can use fake bucket locally instead of real gcp interaction<br/>
To check the content of the bucket run "http://localhost:9023/storage/v1/b"<br/>
The reason for this solution - network on VM has restrictions that do not permit to authenticate on real GCP bucket.

## VI. How to deploy a service
 [Steps to deploy project to the dev openshift cluster](https://github.deutsche-boerse.de/dev/D7.defi-sc/blob/develop/app/bc-event-etl/DEPLOY.md)
 
## VII. Api for testing
This application has set of endpoints that help test all existing flows.<br/>
The swagger documentation can be used by url http://localhost:8091/swagger-ui/index.html <br/>
Samples of requests are available in file src/main/resources/smple_requests.http