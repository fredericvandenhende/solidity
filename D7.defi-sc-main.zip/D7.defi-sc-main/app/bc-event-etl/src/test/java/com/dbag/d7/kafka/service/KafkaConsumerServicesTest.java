package com.dbag.d7.kafka.service;

import com.dbag.d7.bucket.service.TransactionTokenDataUpdateService;
import com.dbag.d7.kafka.service.consumer.KafkaOutputConsumerService;
import com.dbag.d7.kafka.service.consumer.TransactionDataConsumerService;
import com.dbag.d7.kafka.service.producer.AvroProducerService;
import com.dbag.defi.scdeployer.models.Action;
import com.dbag.d7.model.BlockchainOutputMessage;
import com.dbag.defi.scdeployer.models.TransactionTokenData;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.ZonedDateTime;

import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class KafkaConsumerServicesTest {
    @Mock
    TransactionTokenDataUpdateService addressUpdateService;
    @InjectMocks
    private TransactionDataConsumerService addressConsumerService;
    @InjectMocks
    private KafkaOutputConsumerService outputConsumerService;
    @Mock
    private AvroProducerService producerService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void receiveAddressMessage() {
        TransactionTokenData addressSubscription = new TransactionTokenData();
        addressSubscription.setContractAddress("0x0000000000000000000000000000000000001010");
        addressSubscription.setSmartContractUrl("http://someurl");
        addressSubscription.setTransactionRequestId("123");
        addressSubscription.setAction(Action.ADD);
        producerService.sendMessage("defi.bc-event-filter.req.v1", addressSubscription);

        ConsumerRecord<String, TransactionTokenData> consumerRecord =
                new ConsumerRecord<>("requestTopic", 0, 0L, "key", addressSubscription);

        addressConsumerService.receive(consumerRecord);
        // Then
        ArgumentCaptor<String> topicCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<TransactionTokenData> tokenCaptor =
                ArgumentCaptor.forClass(TransactionTokenData.class);

        verify(producerService).sendMessage(topicCaptor.capture(), tokenCaptor.capture());
    }

    @Test
    void receiveBlockchainOutputMessage() {
        BlockchainOutputMessage BlockchainOutputMessage = new BlockchainOutputMessage();
        BlockchainOutputMessage.setRequestTime(ZonedDateTime.now().toString());
        BlockchainOutputMessage.setStatus("Success");
        BlockchainOutputMessage.setMessage("Address added");
        producerService.sendMessage("defi.bc-event-etl-output.v1", BlockchainOutputMessage);

        ConsumerRecord<String, BlockchainOutputMessage> consumerRecord =
                new ConsumerRecord<>(
                        "requestTopic", 0, 0L, "key", BlockchainOutputMessage);
        outputConsumerService.receive(consumerRecord);
        // Then
        ArgumentCaptor<String> topicCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<BlockchainOutputMessage> tokenCaptor =
                ArgumentCaptor.forClass(BlockchainOutputMessage.class);

        verify(producerService).sendMessage(topicCaptor.capture(), tokenCaptor.capture());
    }
}
