package com.dbag.d7.kafka.service;

import com.dbag.d7.kafka.service.producer.JsonProducerService;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.kafka.core.KafkaTemplate;

import static org.mockito.Mockito.verify;

public class KafkaJsonProducerServiceTest {
    @Mock
    private KafkaTemplate<String, String> mockKafkaTemplate;

    @InjectMocks
    private JsonProducerService kafkaProducerService;
    /**
     * Method to test kafka producer sending message to specified topic.
     */
    @Test
    public void testSendMessage() {
        MockitoAnnotations.openMocks(this);
        String topicName = "testTopic";
        String message = "Test kafka message.";

        kafkaProducerService.sendMessage(topicName, message);
        verify(mockKafkaTemplate).send(ArgumentMatchers.anyString(), ArgumentMatchers.any());

    }

}

