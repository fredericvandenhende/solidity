package com.dbag.d7.bucket;

import com.dbag.d7.blockchain.service.RetrieveAbiService;
import com.dbag.d7.bucket.service.impl.TransactionTokenDataUpdateServiceImpl;
import com.dbag.d7.kafka.service.producer.OutputMessageProducerService;
import com.dbag.defi.scdeployer.models.Action;
import com.dbag.defi.scdeployer.models.TransactionTokenData;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TransactionTokenDataUpdateServiceTest {
    @InjectMocks
   private TransactionTokenDataUpdateServiceImpl addressUpdateService;
    @Mock
    private Storage storage;

    @Mock
    private OutputMessageProducerService producerService;

    @Mock
    private Blob blob;
    @Mock
    RetrieveAbiService retrieveAbiService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void readAddressSetEmpty() {
        Assertions.assertTrue(addressUpdateService.readAddressMap().isEmpty());
    }

    @Test
    public void addAddressSuccessMessage() {
        ReflectionTestUtils.setField(addressUpdateService, "storage", storage);
        ReflectionTestUtils.setField(addressUpdateService, "retrieveAbiService", retrieveAbiService);
        ReflectionTestUtils.setField(addressUpdateService, "bucketName", "testbucket");
        ReflectionTestUtils.setField(addressUpdateService, "fileName", "file.txt");
        when(storage.get(anyString(), anyString())).thenReturn(blob);
        when(blob.getContent()).thenReturn("{\"ttt\":\"ttt2\"}".getBytes());
        addressUpdateService.addAddress("2", "abiFinction");
        assert(addressUpdateService.getAddresses().size()==1);

    }

    @Test
    public void clearAddresses() {
        BlobInfo blobInfo = BlobInfo.newBuilder("bucket", "name").build();
        ReflectionTestUtils.setField(addressUpdateService, "blobInfo", blobInfo);
        ReflectionTestUtils.setField(addressUpdateService, "storage", storage);
        addressUpdateService.clearAddresses();
        verify(storage, times(1)).delete(blobInfo.getBlobId());
    }

    //make sure there is no error or exception when the action is wrong
    //the was no message produced
    @Test
    public void unexpectedAction() {
        TransactionTokenData addressSubscription = new TransactionTokenData();
        addressSubscription.setContractAddress("0x0000000000000000000000000000000000001010");
        addressSubscription.setSmartContractUrl("http://someurl");
        addressSubscription.setTransactionRequestId("123");
        addressSubscription.setAction(null);
        addressUpdateService.processAddressSubscription(addressSubscription);
        verify(producerService, times(0)).sendMessage(any());
    }

    @Test
    public void processAddressSubscriptionRemove() {
        TransactionTokenData addressSubscription = new TransactionTokenData();
        addressSubscription.setContractAddress("0x0000000000000000000000000000000000001010");
        addressSubscription.setSmartContractUrl("http://someurl");
        addressSubscription.setTransactionRequestId("123");
        addressSubscription.setAction(Action.REMOVE);
        addressUpdateService.processAddressSubscription(addressSubscription);
    }

    @Test
    public void testGetAddresses() {
        blob = mock(Blob.class);
        ReflectionTestUtils.setField(addressUpdateService, "storage", storage);
        ReflectionTestUtils.setField(addressUpdateService, "bucketName", "testbucket");
        ReflectionTestUtils.setField(addressUpdateService, "fileName", "file.txt");
        when(storage.get("testbucket", "file.txt")).thenReturn(blob);
        when(blob.getContent()).thenReturn("{\"ttt\":\"ttt2\"}".getBytes());
        Map<String, String> result = addressUpdateService.readAddressMap();
        assert(result.size()==1);
        verify(storage, times(1)).get("testbucket", "file.txt");
    }

    @Test
    public void testGetAddressesNullBlob() {
        Map<String, String> addresses = new HashMap<>();
        addresses.put("test1", "test1");
        addresses.put("test2", "test2");
        ReflectionTestUtils.setField(addressUpdateService, "storage", storage);
        ReflectionTestUtils.setField(addressUpdateService, "addresses", addresses);
        ReflectionTestUtils.setField(addressUpdateService, "bucketName", "testbucket");
        ReflectionTestUtils.setField(addressUpdateService, "fileName", "file.txt");
        Map<String, String> result = addressUpdateService.readAddressMap();
        assert(result.size() == 0);
    }
}
