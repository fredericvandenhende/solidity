package com.dbag.d7.kafka.service;

import com.dbag.d7.kafka.service.producer.AvroProducerService;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.kafka.core.KafkaTemplate;

import static org.mockito.Mockito.verify;

public class KafkaAvroProducerServiceTest {
    @Mock
    private KafkaTemplate<String, Object> mockKafkaTemplate;

    @InjectMocks
    private AvroProducerService kafkaProducerService;
    /**
     * Method to test kafka producer sending message to specified topic.
     */
    @Test
    public void testSendMessage() {
        MockitoAnnotations.openMocks(this);
        String topicName = "testTopic";
        Object message = "Test kafka message.";

        kafkaProducerService.sendMessage(topicName, message);
        verify(mockKafkaTemplate).send(ArgumentMatchers.anyString(), ArgumentMatchers.any());

    }

}

