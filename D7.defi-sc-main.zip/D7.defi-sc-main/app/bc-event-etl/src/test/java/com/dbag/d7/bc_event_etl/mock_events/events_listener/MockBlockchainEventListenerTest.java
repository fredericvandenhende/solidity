package com.dbag.d7.bc_event_etl.mock_events.events_listener;

import com.dbag.d7.events.MockBlockchainEvent;
import org.junit.Before;
import org.junit.Test;
import org.web3j.abi.EventEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Address;
import org.web3j.abi.datatypes.Event;
import org.web3j.abi.datatypes.generated.Uint256;
import org.web3j.protocol.core.methods.response.Log;

import java.util.Arrays;
import java.util.Collections;

import static org.mockito.Mockito.*;

public class MockBlockchainEventListenerTest {
    MockBlockchainEventListener mockBlockchainEventListener;

    @Before
    public void setup() {
        mockBlockchainEventListener = mock(MockBlockchainEventListener.class);
    }

    @Test
    public void testListenerEmptyEvent() {
        MockBlockchainEvent mockBlockchainEvent = new MockBlockchainEvent(this, new Log());
        doNothing().when(mockBlockchainEventListener).onApplicationEvent(mockBlockchainEvent);
        mockBlockchainEventListener.onApplicationEvent(mockBlockchainEvent);

        verify(mockBlockchainEventListener, times(1)).onApplicationEvent(any());
    }

    @Test
    public void testListenerOtherEvent() {
        Log log = new Log();
        log.setAddress("0x0012345");

        final Event fakeEvent = new Event("Fake",
                Arrays.asList(
                        new TypeReference<Address>(true) {
                        },
                        new TypeReference<Uint256>(true) {
                        }));
        final String encodedTransferEvent = EventEncoder.encode(fakeEvent);

        log.setTopics(Collections.singletonList(encodedTransferEvent));

        MockBlockchainEvent mockBlockchainEvent = new MockBlockchainEvent(this, log);
        doNothing().when(mockBlockchainEventListener).onApplicationEvent(mockBlockchainEvent);

        mockBlockchainEventListener.onApplicationEvent(mockBlockchainEvent);

        // Assert
        verify(mockBlockchainEventListener, times(1)).onApplicationEvent(any());
    }

    @Test
    public void testListenerTransferEvent() {
        MockBlockchainEventListener mockBlockchainEventListener = mock(MockBlockchainEventListener.class);
        Log log = new Log();
        log.setAddress("0x0012345");

        final Event transferEvent = new Event("Transfer",
                Arrays.asList(
                        new TypeReference<Address>(true) {
                        },
                        new TypeReference<Address>(true) {
                        },
                        new TypeReference<Uint256>(true) {
                        }));

        final String encodedTransferEvent = EventEncoder.encode(transferEvent);

        log.setTopics(Collections.singletonList(encodedTransferEvent));

        MockBlockchainEvent mockBlockchainEvent = new MockBlockchainEvent(this, log);
        doNothing().when(mockBlockchainEventListener).onApplicationEvent(mockBlockchainEvent);

        mockBlockchainEventListener.onApplicationEvent(mockBlockchainEvent);

        // Assert
        verify(mockBlockchainEventListener, times(1)).onApplicationEvent(any());
    }
}