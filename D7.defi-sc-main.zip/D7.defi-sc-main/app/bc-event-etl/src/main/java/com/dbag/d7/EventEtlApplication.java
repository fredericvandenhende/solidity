package com.dbag.d7;

import com.dbag.d7.events.MockBlockchainEventPublisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.annotation.PostConstruct;

@SpringBootApplication(scanBasePackages={"com.dbag.d7"})
public class EventEtlApplication {

    @Autowired
    MockBlockchainEventPublisher mockBlockchainEventPublisher;

    public static void main(String[] args) {
        SpringApplication.run(EventEtlApplication.class, args);
    }

    @PostConstruct
    void init() throws InterruptedException {
         mockBlockchainEventPublisher.randomEventsPublisher();
    }
}