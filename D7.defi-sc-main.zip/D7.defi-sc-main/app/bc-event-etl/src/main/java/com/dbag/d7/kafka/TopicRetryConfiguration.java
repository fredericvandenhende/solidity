package com.dbag.d7.kafka;

import org.springframework.context.annotation.Bean;
import org.springframework.kafka.core.*;
import org.springframework.kafka.retrytopic.RetryTopicConfiguration;
import org.springframework.kafka.retrytopic.RetryTopicConfigurationBuilder;

public class TopicRetryConfiguration {
  @Bean
  public <T> RetryTopicConfiguration retryTopicConfiguration(KafkaTemplate<String, T> template) {
    return RetryTopicConfigurationBuilder.newInstance()
        .maxAttempts(3)
        .exponentialBackoff(1000, 2, 3000)
        .suffixTopicsWithIndexValues()
        .create(template);
  }
}
