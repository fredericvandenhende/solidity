package com.dbag.d7.blockchain.util;

import com.dbag.d7.blockchain.definition.AbiDefinition;
import org.bouncycastle.util.encoders.Hex;

import java.util.HashMap;
import java.util.Map;

public class AbiDecoder {

    private final AbiDefinition abi;

    public Map<String, AbiDefinition.Entry> getMethodSignatures() {
        return methodSignatures;
    }

    final Map<String, AbiDefinition.Entry> methodSignatures = new HashMap<>();

    public AbiDecoder(String abiJson) {
        this.abi = AbiDefinition.fromJson(abiJson.replace("\n", ""));
        init();
    }


    private void init() {
        for (AbiDefinition.Entry entry : this.abi) {
            String hexEncodedMethodSignature = Hex.toHexString(entry.encodeSignature());
            this.methodSignatures.put(hexEncodedMethodSignature, entry);
        }
    }

    }
