package com.dbag.d7.blockchain.definition;

import com.dbag.d7.blockchain.util.ByteUtil;

import java.util.Arrays;

public class BytesType extends SolidityType {
    protected BytesType(String name) {
        super(name);
    }

    public BytesType() {
        super("bytes");
    }

    @Override
    public byte[] encode(Object value) {
        byte[] bb;
        if (value instanceof byte[]) {
            bb = (byte[]) value;
        } else if (value instanceof String) {
            bb = ((String) value).getBytes();
        } else {
            throw new RuntimeException("byte[] or String value is expected for type 'bytes'");
        }
        byte[] ret = new byte[((bb.length - 1) / Int32Size + 1) * Int32Size]; // padding 32 bytes
        System.arraycopy(bb, 0, ret, 0, bb.length);

        return ByteUtil.merge(IntType.encodeInt(bb.length), ret);
    }

    @Override
    public Object decode(byte[] encoded, int offset) {
        int len = IntType.decodeInt(encoded, offset).intValue();
        if (len == 0) return new byte[0];
        offset += Int32Size;
        return Arrays.copyOfRange(encoded, offset, offset + len);
    }

    @Override
    public boolean isDynamicType() {
        return true;
    }
}
