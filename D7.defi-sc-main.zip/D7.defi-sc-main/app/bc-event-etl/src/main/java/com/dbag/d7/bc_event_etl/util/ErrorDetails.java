package com.dbag.d7.bc_event_etl.util;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(enumAsRef = true)
public enum ErrorDetails {
  UNABLE_TO_DECODE("Impossible to decode the event with existing abi definition"),
  UNABLE_TO_READ_ABI("The abi is malformed or unavailable"),
  INVALID_ADDRESS("There is no valid address in the event."),
  UNABLE_UNSUBSCRIBE("The address %s is not on the list. Unable to unsubscribe."),
  INVALID_KAFKA_MESSAGE("The message does not contain all necessary fields or malformed. The event is - %s");

  public String getErrorMessage() {
    return errorMessage;
  }

  private final String errorMessage;

  ErrorDetails(String errorMessage) {
    this.errorMessage = errorMessage;
  }
}