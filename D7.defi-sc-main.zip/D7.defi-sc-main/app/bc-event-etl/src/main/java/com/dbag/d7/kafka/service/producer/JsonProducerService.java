package com.dbag.d7.kafka.service.producer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class JsonProducerService {
    private static final Logger log = LoggerFactory.getLogger(JsonProducerService.class);

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    public void sendMessage(String topicName, String message) {
        log.info("Producing Kafka message to topic {} with value {}", topicName, message);
        kafkaTemplate.send(topicName, message);
    }

}
