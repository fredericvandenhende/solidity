package com.dbag.d7.kafka.service.producer;

import com.dbag.defi.scdeployer.models.TransactionTokenData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class AddressAbiFilterProducerService {
    private final AvroProducerService producerService;

    @Value("${request.topic}")
    String sendMessage;

    @Autowired
    public AddressAbiFilterProducerService(AvroProducerService producerService) {
        this.producerService = producerService;
    }
    public void sendMessage(TransactionTokenData transactionTokenData){
        producerService.sendMessage(sendMessage, transactionTokenData);
    }
}
