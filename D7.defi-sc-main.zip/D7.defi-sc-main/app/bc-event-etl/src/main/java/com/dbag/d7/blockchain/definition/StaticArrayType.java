package com.dbag.d7.blockchain.definition;

import java.util.List;

public class StaticArrayType extends ArrayType {
    final int size;

    public StaticArrayType(String name) {
        super(name);
        int idx1 = name.lastIndexOf("[");
        int idx2 = name.lastIndexOf("]");
        String dim = name.substring(idx1 + 1, idx2);
        size = Integer.parseInt(dim);
    }

    @Override
    public String getCanonicalName() {
        return getElementType().getCanonicalName() + "[" + size + "]";
    }

    @Override
    public byte[] encodeList(List l) {
        if (l.size() != size)
            throw new RuntimeException("List size (" + l.size() + ") != " + size + " for type " + getName());
        return encodeTuple(l);
    }

    @Override
    public Object[] decode(byte[] encoded, int offset) {
        return decodeTuple(encoded, offset, size);
    }

    @Override
    public int getFixedSize() {
        if (isDynamicType()) {
            return Int32Size;
        } else {
            return elementType.getFixedSize() * size;
        }
    }

    @Override
    public boolean isDynamicType() {
        return getElementType().isDynamicType() && size > 0;
    }
}
