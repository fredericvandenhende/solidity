package com.dbag.d7.bc_event_etl.util;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(enumAsRef = true)
public enum Status {
    ERROR,
    SUCCESS,
    WARN
}
