package com.dbag.d7.kafka.service.producer;

import com.dbag.d7.bc_event_etl.util.ErrorDetails;
import com.dbag.d7.bc_event_etl.util.Status;
import com.dbag.d7.bc_event_etl.util.SuccessDetails;
import com.dbag.d7.bc_event_etl.util.WarningDetails;
import com.dbag.d7.model.BlockchainOutputMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.ZonedDateTime;

@Service
public class OutputMessageProducerService {
    private final AvroProducerService producerService;

    @Value("${response.topic}")
    String sendMessage;

    @Autowired
    public OutputMessageProducerService(AvroProducerService producerService) {
        this.producerService = producerService;
    }

    public void sendMessage(BlockchainOutputMessage blockchainOutputMessage) {
        producerService.sendMessage(sendMessage, blockchainOutputMessage);
    }

    public void sendErrorMessage(ErrorDetails errorDetails) {
        BlockchainOutputMessage message = new BlockchainOutputMessage();
        message.setRequestTime(ZonedDateTime.now().toString());
        message.setStatus(Status.ERROR.name());
        message.setDetails(errorDetails.name());
        message.setMessage(String.format(errorDetails.getErrorMessage()));
        sendMessage(message);
    }

    public void sendErrorMessage(String address, ErrorDetails errorDetails) {
        BlockchainOutputMessage message = new BlockchainOutputMessage();
        message.setRequestTime(ZonedDateTime.now().toString());
        message.setStatus(Status.ERROR.name());
        message.setDetails(errorDetails.name());
        message.setMessage(String.format(errorDetails.getErrorMessage(), address));
        sendMessage(message);
    }

    public void sendSuccessMessage(String address, SuccessDetails successDetails) {
        BlockchainOutputMessage message = new BlockchainOutputMessage();
        message.setRequestTime(ZonedDateTime.now().toString());
        message.setStatus(Status.SUCCESS.name());
        message.setDetails(successDetails.name());
        message.setMessage(String.format(successDetails.getMessage(), address));
        sendMessage(message);
    }

    public void sendWarningMessage(String address) {
        BlockchainOutputMessage message = new BlockchainOutputMessage();
        message.setRequestTime(ZonedDateTime.now().toString());
        message.setStatus(Status.WARN.name());
        message.setDetails(WarningDetails.ADDRESS_ALREADY_EXISTS.name());
        message.setMessage(String.format(WarningDetails.ADDRESS_ALREADY_EXISTS.getMessage(), address));
        sendMessage(message);
    }


}
