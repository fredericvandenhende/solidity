package com.dbag.d7.bucket.service;

import com.dbag.defi.scdeployer.models.TransactionTokenData;

import java.util.Map;

public interface TransactionTokenDataUpdateService {
    Map<String, String> readAddressMap();
    void processAddressSubscription(TransactionTokenData addressSubscription);
    void clearAddresses();
    Map<String, String> getAddresses();
}
