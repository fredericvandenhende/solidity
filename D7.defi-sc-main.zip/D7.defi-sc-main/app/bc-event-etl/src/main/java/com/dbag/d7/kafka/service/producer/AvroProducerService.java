package com.dbag.d7.kafka.service.producer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

/**
 * Service class responsible for producing messages to Kafka topics. This class contains methods to
 * handle message processing and logic related to Kafka message production.
 */
@Service
public class AvroProducerService {
  private static final Logger log = LoggerFactory.getLogger(AvroProducerService.class);

  private final KafkaTemplate<String, Object> kafkaTemplate;

  @Autowired
  public AvroProducerService(KafkaTemplate<String, Object> kafkaTemplate) {
    this.kafkaTemplate = kafkaTemplate;
  }
  /**
   * This method sends a message to the specified Kafka topic using the provided message object.
   *
   * @param topicName
   * @param message
   */
  public void sendMessage(String topicName, Object message) {
    log.info("Producing Kafka message to topic {} with value {}", topicName, message.toString());
    kafkaTemplate.send(topicName, message);
    log.info("Kafka message produced");
  }
}
