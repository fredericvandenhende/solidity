package com.dbag.d7.blockchain.definition;

import com.dbag.d7.blockchain.util.ByteUtil;

public class FunctionType extends Bytes32Type {
    public FunctionType() {
        super("function");
    }

    @Override
    public byte[] encode(Object value) {
        if (!(value instanceof byte[])) throw new RuntimeException("Expected byte[] value for FunctionType");
        if (((byte[]) value).length != 24) throw new RuntimeException("Expected byte[24] for FunctionType");
        return super.encode(ByteUtil.merge((byte[]) value, new byte[8]));
    }
}
