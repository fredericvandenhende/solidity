package com.dbag.d7.blockchain.definition;

import com.dbag.d7.blockchain.util.ByteUtil;

import java.math.BigInteger;
import java.util.Arrays;

public class UnsignedIntType extends NumericType {
    public UnsignedIntType(String name) {
        super(name);
    }

    public static BigInteger decodeInt(byte[] encoded, int offset) {
        return new BigInteger(1, Arrays.copyOfRange(encoded, offset, offset + Int32Size));
    }

    public static byte[] encodeInt(int i) {
        return encodeInt(new BigInteger(String.valueOf(i)));
    }

    public static byte[] encodeInt(BigInteger bigInt) {
        if (bigInt.signum() == -1) {
            throw new RuntimeException("Wrong value for uint type: " + bigInt);
        }
        return ByteUtil.bigIntegerToBytes(bigInt, Int32Size);
    }

    @Override
    public String getCanonicalName() {
        if (getName().equals("uint")) return "uint256";
        return super.getCanonicalName();
    }

    @Override
    public byte[] encode(Object value) {
        BigInteger bigInt = encodeInternal(value);
        return encodeInt(bigInt);
    }

    @Override
    public Object decode(byte[] encoded, int offset) {
        return decodeInt(encoded, offset);
    }
}
