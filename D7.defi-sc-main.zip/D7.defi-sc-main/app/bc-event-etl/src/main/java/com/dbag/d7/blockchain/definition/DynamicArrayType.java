package com.dbag.d7.blockchain.definition;

import com.dbag.d7.blockchain.util.ByteUtil;

import java.util.List;

public class DynamicArrayType extends ArrayType {
    public DynamicArrayType(String name) {
        super(name);
    }

    @Override
    public String getCanonicalName() {
        return elementType.getCanonicalName() + "[]";
    }

    @Override
    public byte[] encodeList(List l) {
        return ByteUtil.merge(IntType.encodeInt(l.size()), encodeTuple(l));
    }

    @Override
    public Object decode(byte[] encoded, int origOffset) {
        int len = IntType.decodeInt(encoded, origOffset).intValue();
        return decodeTuple(encoded, origOffset + Int32Size, len);
    }

    @Override
    public boolean isDynamicType() {
        return true;
    }
}
