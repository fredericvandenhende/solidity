package com.dbag.d7.bucket.service.impl;

import com.dbag.d7.bc_event_etl.util.ErrorDetails;
import com.dbag.d7.bc_event_etl.util.SuccessDetails;
import com.dbag.d7.blockchain.service.RetrieveAbiService;
import com.dbag.d7.bucket.service.TransactionTokenDataUpdateService;
import com.dbag.d7.kafka.service.producer.OutputMessageProducerService;
import com.dbag.defi.scdeployer.models.Action;
import com.dbag.defi.scdeployer.models.TransactionTokenData;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static java.nio.charset.StandardCharsets.UTF_8;

//this test will be running only on the local environment
@Service
public class TransactionTokenDataUpdateServiceImpl implements TransactionTokenDataUpdateService {
    private static final Logger logger = LoggerFactory.getLogger(TransactionTokenDataUpdateServiceImpl.class);

    private final OutputMessageProducerService producerService;
    private final RetrieveAbiService retrieveAbiService;

    @Value("${gcp.bucket.name}")
    private String bucketName;

    @Value("${gcp.address.filename}")
    private String fileName;

    @Value("${spring.profiles.active}")
    private String profile;

    private final Storage storage;
    private Blob blob;
    private BlobInfo blobInfo;
    private final ObjectMapper mapper = new ObjectMapper();

    private Map<String, String> addresses = new HashMap<>();

    @Autowired
    public TransactionTokenDataUpdateServiceImpl(Storage storage,
                                                 OutputMessageProducerService producerService,
                                                 RetrieveAbiService retrieveAbiService) {
        this.storage = storage;
        this.producerService = producerService;
        this.retrieveAbiService = retrieveAbiService;
    }

    @PostConstruct
    public void initialize() {
        BlobId blobId = BlobId.of(bucketName, fileName);
        blobInfo = BlobInfo.newBuilder(blobId).build();
        addresses = readAddressMap();
    }

    public void processAddressSubscription(TransactionTokenData addressSubscription) {
        String address = addressSubscription.getContractAddress().toString().toLowerCase();
    if (addresses == null) {
            producerService.sendErrorMessage(ErrorDetails.INVALID_ADDRESS);
        } else {
            if (Action.ADD.equals(addressSubscription.getAction())) {
                logger.info("Adding subscription - " + address + " url - "
                        + addressSubscription.getSmartContractUrl().toString());
                addAddress(address,
                        addressSubscription.getSmartContractUrl().toString());
            } else if (Action.REMOVE.equals(addressSubscription.getAction())) {
                logger.info("Deleting subscription - " + address
                        + " url - " + addressSubscription.getSmartContractUrl().toString());
                removeAddress(address);
            } else {
                logger.info("Wrong action");
            }
        }
    }

    @Override
    public Map<String, String> getAddresses() {
        return addresses;
    }

    @SuppressWarnings("unchecked")
    @Override
    public Map<String, String> readAddressMap() {
        blob = storage.get(bucketName, fileName);
        logger.info("blob = " + blob + " addresses - " + addresses);
        if (blob == null) {
            addresses.clear();
            return addresses;
        }

        ByteArrayResource resource = new ByteArrayResource(blob.getContent());
        String json = new String(resource.getByteArray());
        try {
            addresses = mapper.readValue(json, Map.class);
            return addresses;
        } catch (IOException e) {
            logger.error("Can't read json - " + Arrays.toString(e.getStackTrace()));
        }
        return new HashMap<>();
    }

    public void addAddress(String address, String url) {
        addresses = readAddressMap();
        if (addresses.containsKey(address)) {
            producerService.sendWarningMessage(address);
            logger.info("Address is already in the list.");
        } else {
            //If profile is not defined, the abi will be used from local file, otherwise from remote url
            String abi = profile == null || profile.equals("") ? retrieveAbiService.mockRetrieveAbiFromUrl() :
                    retrieveAbiService.retrieveAbifromUrl(url);
            if (abi != null) {
                addresses.put(address, abi);
                saveAddressMap(addresses);
                producerService.sendSuccessMessage(address, SuccessDetails.ADDRESS_ADDED);
                logger.info("Address " + address + " was successfully added");
            } else {
                producerService.sendErrorMessage(address, ErrorDetails.UNABLE_TO_READ_ABI);
            }
        }
    }


    public void removeAddress(String address) {
        addresses = readAddressMap();
        if (addresses.containsKey(address)) {
            addresses.remove(address);
            saveAddressMap(addresses);
            producerService.sendSuccessMessage(address, SuccessDetails.ADDRESS_REMOVED);
            logger.info("Address " + address + " was successfully removed");
        } else {
            producerService.sendErrorMessage(address, ErrorDetails.UNABLE_UNSUBSCRIBE);
            logger.info("Address is not on the list, cant remove");
        }
    }

    private void saveAddressMap(Map<String, String> addresses) {
        try {
            // convert map to JSON string
            String json = mapper.writeValueAsString(addresses);
            logger.info("<-------------Saving address map = " + json);
            byte[] content = json.getBytes(UTF_8);
            blob = storage.create(blobInfo, content);

            json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(addresses);
            logger.info(json);   // pretty-print

        } catch (JsonProcessingException e) {
            logger.error("!!!Can't save address map - " + Arrays.toString(e.getStackTrace()));
        }
    }

    @Override
    public void clearAddresses() {
        if (blobInfo != null) storage.delete(blobInfo.getBlobId());
        logger.info("Blob is deleted.");
    }
}
