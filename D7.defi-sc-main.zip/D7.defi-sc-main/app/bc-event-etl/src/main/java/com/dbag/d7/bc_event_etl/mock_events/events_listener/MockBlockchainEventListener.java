package com.dbag.d7.bc_event_etl.mock_events.events_listener;

import com.dbag.d7.bc_event_etl.util.ErrorDetails;
import com.dbag.d7.blockchain.definition.AbiDefinition;
import com.dbag.d7.blockchain.util.AbiDecoder;
import com.dbag.d7.bucket.service.TransactionTokenDataUpdateService;
import com.dbag.d7.events.MockBlockchainEvent;
import com.dbag.d7.kafka.service.producer.BlockchainEventProducerService;
import com.dbag.d7.kafka.service.producer.OutputMessageProducerService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.web3j.abi.FunctionReturnDecoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Type;
import org.web3j.protocol.core.methods.response.Log;

import java.io.IOException;
import java.util.Map;

@Component
@ComponentScan("com.dbag.d7.kafka.service")
public class MockBlockchainEventListener implements ApplicationListener<MockBlockchainEvent> {
    private static final Logger log = LoggerFactory.getLogger(MockBlockchainEventListener.class);

    @Autowired
    private BlockchainEventProducerService eventProducerService;

    @Autowired
    private OutputMessageProducerService outputProducerService;

    @Autowired
    private TransactionTokenDataUpdateService addressUpdateService;

    private Map<String, String> addressesAbiMap;

    @Override
    public void onApplicationEvent(final MockBlockchainEvent mockBlockchainEvent) {
        addressesAbiMap = addressUpdateService.getAddresses();

        Log event = mockBlockchainEvent.getMessage();
        log.info("Received event - {}", event);

        if (event.getAddress() != null && addressesAbiMap.containsKey(event.getAddress())) {
            ObjectNode eventNode = createEventJson(event);
            if (eventNode != null) {
                log.info("Producing kafka message with BC event - " + eventNode);
                eventProducerService.sendMessage(eventNode.toString());
            } else log.info("Unable to decode event");
        } else {
            log.info("there is no abi for address " + event.getAddress());
        }
    }

    private ObjectNode createEventJson(Log event) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            AbiDefinition.Entry entry = getEntryFromAbi(mapper, event);
            if (entry == null) {
                outputProducerService.sendErrorMessage(ErrorDetails.UNABLE_TO_DECODE);
                return null;
            }
            ObjectNode rootNode = mapper.createObjectNode();
            rootNode.put("event", entry.name);
            rootNode.put("logIndex", event.getLogIndex());
            rootNode.put("transactionIndex", event.getTransactionIndex());
            rootNode.put("transactionHash", event.getTransactionHash());
            rootNode.put("blockHash", event.getBlockHash());
            rootNode.put("blockNumber", event.getBlockNumber());
            rootNode.put("address", event.getAddress());
            rootNode.put("data", event.getData());
            rootNode.put("type", event.getType());

            ObjectNode params = mapper.createObjectNode();
            for (int i = 0; i < entry.inputs.size(); i++) {
                try {
                    AbiDefinition.Entry.Param param = entry.inputs.get(i);
                    Type type = FunctionReturnDecoder.decodeIndexedValue(event.getTopics().get(i + 1),
                            TypeReference.makeTypeReference(param.getType().toString()));
                    params.put(param.getName(), type.getValue().toString());
                } catch (ClassNotFoundException e) {
                    outputProducerService.sendErrorMessage(ErrorDetails.UNABLE_TO_DECODE);
                }

            }
            rootNode.set("inputs", params);
            return rootNode;

        } catch (IOException e) {
            outputProducerService.sendErrorMessage(ErrorDetails.UNABLE_TO_READ_ABI);
        }
        return null;
    }

    private AbiDefinition.Entry getEntryFromAbi(ObjectMapper mapper, Log event) throws IOException {
        String contractJson = addressesAbiMap.get(event.getAddress());
        String abi = mapper.readTree(contractJson).toString();
        AbiDecoder decoder = new AbiDecoder(abi);
        return decoder.getMethodSignatures().get(event.getTopics().get(0).substring(2));
    }
}