package com.dbag.d7.blockchain.definition;

import java.nio.charset.StandardCharsets;

public class StringType extends BytesType {
    public StringType() {
        super("string");
    }

    @Override
    public byte[] encode(Object value) {
        if (!(value instanceof String)) throw new RuntimeException("String value expected for type 'string'");
        return super.encode(((String) value).getBytes(StandardCharsets.UTF_8));
    }

    @Override
    public Object decode(byte[] encoded, int offset) {
        return new String((byte[]) super.decode(encoded, offset), StandardCharsets.UTF_8);
    }
}
