package com.dbag.d7.web;

import com.dbag.d7.bc_event_etl.util.ErrorDetails;
import com.dbag.d7.bc_event_etl.util.Status;
import com.dbag.d7.bc_event_etl.util.SuccessDetails;
import com.dbag.d7.bc_event_etl.util.WarningDetails;
import com.dbag.d7.bucket.service.TransactionTokenDataUpdateService;
import com.dbag.d7.events.MockBlockchainEvent;
import com.dbag.d7.kafka.service.producer.OutputMessageProducerService;
import com.dbag.defi.scdeployer.models.Action;
import com.dbag.defi.scdeployer.models.TransactionTokenData;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.web3j.abi.EventEncoder;
import org.web3j.abi.TypeEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Address;
import org.web3j.abi.datatypes.Event;
import org.web3j.abi.datatypes.generated.Uint256;
import org.web3j.protocol.core.methods.response.Log;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
public class Controller {
    private final OutputMessageProducerService outputMessageProducerService;
    private final TransactionTokenDataUpdateService addressUpdateService;
    private static final Logger logger = LoggerFactory.getLogger(Controller.class);

    public Controller(ApplicationEventPublisher applicationEventPublisher,
                      OutputMessageProducerService outputMessageProducerService,
                      TransactionTokenDataUpdateService addressUpdateService) {
        this.applicationEventPublisher = applicationEventPublisher;
        this.outputMessageProducerService = outputMessageProducerService;
        this.addressUpdateService = addressUpdateService;
    }

    @Operation(summary = "Based on the status, details and address(optional) sends SUCCESS/WARN/ERROR message.")
    @ApiResponse(responseCode = "200", description = "Post method to push BlockchainOutputMessage kafka messages to bc-event-etl-output topic",
            content = {@Content(schema = @Schema(implementation = GenericResponse.class))})
    @PostMapping("/outputMessages")
    @ResponseBody
    public ResponseEntity<GenericResponse> sendOutputMessage(@RequestParam(name = "status") @NotNull @Schema(implementation = Status.class) String status,
                                                             @NotNull @RequestParam(name = "details") @Parameter(
                                                                     description = "Here is the description of the fields that can be added:<br/>" +
                                                                             "##status - SUCCESS <br/>" +
                                                                             "- details - EVENT_RECEIVED, needs address, <br/>" +
                                                                             "- details - ADDRESS_ADDED, needs address,<br/>" +
                                                                             "- details - ADDRESS_REMOVED, needs address,<br/>" +
                                                                             "##status - WARN <br/>" +
                                                                             "- details - ADDRESS_ALREADY_EXISTS, needs address,<br/>" +
                                                                             "##status - ERROR <br/>" +
                                                                             "- details - UNABLE_TO_DECODE, NO address needed, <br/>" +
                                                                             "- details - UNABLE_TO_READ_ABI, NO address needed,<br/>" +
                                                                             "- details - INVALID_ADDRESS, NO address needed,<br/>" +
                                                                             "- details - UNABLE_UNSUBSCRIBE, needs address, <br/>" +
                                                                             "- details - INVALID_KAFKA_MESSAGE, needs address",
                                                                     required = true
                                                                     , examples = {
                                                                     @ExampleObject(name = "One of success messages", value = "ADDRESS_REMOVED"),
                                                                     @ExampleObject(name = "One of WARN messages", value = "ADDRESS_ALREADY_EXISTS"),
                                                                     @ExampleObject(name = "One of ERROR messages", value = "INVALID_ADDRESS")})
                                                             String details,
                                                             @RequestParam(name = "address", required = false) String address) {

        GenericResponse resp = new GenericResponse();
        resp.setStatus(HttpStatus.BAD_REQUEST.name());
        resp.setCode(HttpStatus.BAD_REQUEST.value());
        resp.setData("Status - " + status + " Details - " + details + " address - " + address);
        resp.setMessage("Invalid details status");
        switch (status) {
            case "SUCCESS" -> {
                SuccessDetails successDetails = findSuccessDetails(details);
                if (successDetails == null) {
                    return new ResponseEntity<>(resp, HttpStatus.valueOf(resp.getCode()));
                }
                outputMessageProducerService.sendSuccessMessage(address, successDetails);
            }
            case "WARN" -> {
                WarningDetails warningDetails = findWarnDetails(details);
                if (warningDetails == null) {
                    return new ResponseEntity<>(resp, HttpStatus.valueOf(resp.getCode()));
                }
                outputMessageProducerService.sendWarningMessage(address);
            }
            case "ERROR" -> {
                ErrorDetails errorDetails = findErrorDetails(details);
                if (errorDetails == null) {
                    return new ResponseEntity<>(resp, HttpStatus.valueOf(resp.getCode()));
                }
                outputMessageProducerService.sendErrorMessage(address, errorDetails);
            }
            default -> {
                resp.setMessage("The status is Wrong");
                return new ResponseEntity<>(resp, HttpStatus.valueOf(resp.getCode()));
            }
        }
        resp.setStatus(HttpStatus.OK.name());
        resp.setCode(HttpStatus.OK.value());
        resp.setData("Status - " + status + " Details - " + details + " address - " + address);
        resp.setMessage("Successfully sent a message");
        return new ResponseEntity<>(resp, HttpStatus.valueOf(resp.getCode()));
    }

    private ErrorDetails findErrorDetails(String details) {
        return switch (details) {
            case "UNABLE_TO_DECODE" -> ErrorDetails.UNABLE_TO_DECODE;
            case "UNABLE_TO_READ_ABI" -> ErrorDetails.UNABLE_TO_READ_ABI;
            case "INVALID_ADDRESS" -> ErrorDetails.INVALID_ADDRESS;
            case "UNABLE_UNSUBSCRIBE" -> ErrorDetails.UNABLE_UNSUBSCRIBE;
            case "INVALID_KAFKA_MESSAGE" -> ErrorDetails.INVALID_KAFKA_MESSAGE;
            default -> null;
        };
    }

    private WarningDetails findWarnDetails(String details) {
        if (details.equals(WarningDetails.ADDRESS_ALREADY_EXISTS.name())) return WarningDetails.ADDRESS_ALREADY_EXISTS;
        return null;
    }

    private SuccessDetails findSuccessDetails(String details) {
        return switch (details) {
            case "EVENT_RECEIVED" -> SuccessDetails.EVENT_RECEIVED;
            case "ADDRESS_ADDED" -> SuccessDetails.ADDRESS_ADDED;
            case "ADDRESS_REMOVED" -> SuccessDetails.ADDRESS_REMOVED;
            default -> null;
        };
    }

    @Operation(summary = "Based on the address and action updates the file in a bucket with contract subscription.")
    @ApiResponse(responseCode = "200", description = "Successfully pushed AddressContractSubscription kafka messages to bc-event-filter topic",
            content = {@Content(schema = @Schema(implementation = GenericResponse.class))})
    @PostMapping("/addressAbiSubscriptions")
    @ResponseBody
    public ResponseEntity<GenericResponse> handleAddressSubscription(@RequestParam(name = "address") @NotNull String address,
                                                                     @NotNull @RequestParam(name = "action")
                                                                     @Schema(implementation = Action.class) String action,
                                                                     @RequestParam(name="url",
                                                                             defaultValue = "http://sc-template-manager-service.d7devint-d7defisvc.svc.cluster.local:8091/sctemplate/v1/templates/commercialpapaer-security/v1.0")
                                                                         String url)
    {
        com.dbag.defi.scdeployer.models.Action actionValue = null;
        if (action.equals(Action.ADD.name())) {
            actionValue = Action.ADD;
        } else if (action.equals(Action.REMOVE.name())) {
            actionValue = Action.REMOVE;
        }

        GenericResponse resp = new GenericResponse();
        if (actionValue != null) {
            TransactionTokenData addressContractSubscription = new TransactionTokenData();
            addressContractSubscription.setContractAddress(address);
            addressContractSubscription.setTransactionRequestId("1234");
            addressContractSubscription.setAction(actionValue);
            addressContractSubscription.setSmartContractUrl(url);
            addressContractSubscription.setResponseMessage("The action "+ actionValue + " with the address " + address);
            addressUpdateService.processAddressSubscription(addressContractSubscription);

            resp.setStatus(HttpStatus.OK.name());
            resp.setCode(HttpStatus.OK.value());
            resp.setData("Address - " + address + " Action - " + action);
            resp.setMessage("Successfully handled " + actionValue + " for address " + address);
        } else {
            resp.setStatus(HttpStatus.BAD_REQUEST.name());
            resp.setCode(HttpStatus.BAD_REQUEST.value());
            resp.setData("Address - " + address + " Action - " + action);
            resp.setMessage("Incorrect action. Should choose ADD or REMOVE");
            logger.info("Incorrect action. Should choose ADD or REMOVE.");
        }
        return new ResponseEntity<>(resp, HttpStatus.valueOf(resp.getCode()));
    }

    final ObjectMapper objectMapper = new ObjectMapper();

    @Operation(summary = "Emits blockchain event based on the json object in from the body of request")
    @ApiResponse(responseCode = "200", description = "Post method to push kafka messages with Decoded blockchain event " +
            " to bc-event.update topic", content = {@Content(schema = @Schema(implementation = GenericResponse.class))})
    @PostMapping("/blockchainEvents")
    public ResponseEntity<GenericResponse> emitBlockchainEvent(@io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "json that represents blockchain event",
            content = @Content(
                    schema = @Schema(
                            type = "string",
                            format = "json"),
                    examples = {
                            @ExampleObject(name = "Approval", value = """
                                    { "address": "0x0000000000000000000000000000000000001010",
                                      "name": "Approval",
                                      "from": "1324567890",
                                      "to": "132456789",
                                      "amount" : 30
                                    }"""),
                            @ExampleObject(name = "Transfer", value = """
                                    { "address": "0x0000000000000000000000000000000000001010",
                                      "name": "Transfer",
                                      "from": "1324567890",
                                      "to": "1324567898",
                                      "amount" : 30
                                    }"""),
                    })) @RequestBody String body) {
        System.out.println("Event emitted - " + body);
        GenericResponse resp;
        try {
            JsonNode jsonNode = objectMapper.readTree(body);
            resp = processEvent(jsonNode);
        } catch (JsonProcessingException e) {
            logger.info("Unable to parse a json");
            resp = new GenericResponse();
            resp.setStatus(HttpStatus.BAD_REQUEST.name());
            resp.setCode(HttpStatus.BAD_REQUEST.value());
            resp.setData(body);
            resp.setMessage("Unable to parse a json");
        }
        return new ResponseEntity<>(resp, HttpStatus.valueOf(resp.getCode()));
    }

    private GenericResponse processEvent(JsonNode jsonNode) {
        String event = jsonNode.get("name").asText();
        GenericResponse resp = new GenericResponse();
        switch (event) {
            case "Approval" -> {
                processApproval(jsonNode);
                resp.setStatus(HttpStatus.OK.name());
                resp.setCode(HttpStatus.OK.value());
                resp.setData(jsonNode);
                resp.setMessage("Successfully handled Mint");
            }
            case "Transfer" -> {
                processTransfer(jsonNode);
                resp.setStatus(HttpStatus.OK.name());
                resp.setCode(HttpStatus.OK.value());
                resp.setData(jsonNode);
                resp.setMessage("Successfully handled Transfer");
            }
            default -> {
                logger.info("The event is not recognised");
                resp.setStatus(HttpStatus.BAD_REQUEST.name());
                resp.setCode(HttpStatus.BAD_REQUEST.value());
                resp.setData(jsonNode);
                resp.setMessage("The event is not recognised");
            }
        }
        return resp;
    }

    private void processTransfer(JsonNode jsonNode) {
        Address address = new Address(jsonNode.get("address").asText());
        Address from = new Address(jsonNode.get("from").asText());
        Address to = new Address(jsonNode.get("to").asText());
        Uint256 value = new Uint256(jsonNode.get("amount").longValue());
        sendTransfer(address, from, to, value);
    }

    private void processApproval(JsonNode jsonNode) {
        Address address = new Address(jsonNode.get("address").asText());
        Address from = new Address(jsonNode.get("from").asText());
        Address to = new Address(jsonNode.get("to").asText());
        Uint256 value = new Uint256(jsonNode.get("amount").longValue());
        sendApproval(address, from, to, value);
    }

    private final ApplicationEventPublisher applicationEventPublisher;

    private String encodedEvent;
    private Log log = new Log();
    private final List<String> topics = new ArrayList<>();

    //TODO Add events
    //PropertyChanged("decimals", "uint8", oldValue, _decimals) - and other fields
    //ChangeStatus(oldStatus, _status);

    final Event burnAndMint = new Event("Transfer",
            Arrays.asList(
                    new TypeReference<Address>(true) {
                    },
                    new TypeReference<Address>(true) {
                    },
                    new TypeReference<Uint256>(false) {
                    }));

    final Event approvalEvent = new Event("Approval",
            Arrays.asList(
                    new TypeReference<Address>(true) {
                    },
                    new TypeReference<Address>(true) {
                    },
                    new TypeReference<Uint256>(false) {
                    }));

    private void sendTransfer(Address address, Address from, Address to, Uint256 value) {
        // Encode the event
        encodedEvent = EventEncoder.encode(burnAndMint);

        log = new Log();
        log.setAddress(address.toString());
        log.setBlockNumber("123456");
        log.setTransactionHash("0x123456789");

        topics.clear();
        topics.add(encodedEvent);
        topics.add(TypeEncoder.encode(from));
        topics.add(TypeEncoder.encode(to));
        topics.add(TypeEncoder.encode(value));
        log.setTopics(topics);

        System.out.println("Publishing transfer event " + log);
        final MockBlockchainEvent mockBlockchainEvent = new MockBlockchainEvent(this, log);

        applicationEventPublisher.publishEvent(mockBlockchainEvent);
    }

    private void sendApproval(Address address, Address from, Address to, Uint256 value) {
        // Encode the event
        encodedEvent = EventEncoder.encode(approvalEvent);

        log = new Log();
        log.setAddress(address.toString());
        log.setBlockNumber("123456");
        log.setTransactionHash("0x123456789");

        topics.clear();
        topics.add(encodedEvent);
        topics.add(TypeEncoder.encode(from));
        topics.add(TypeEncoder.encode(to));
        topics.add(TypeEncoder.encode(value));
        log.setTopics(topics);

        System.out.println("Publishing transfer event " + log);
        final MockBlockchainEvent mockBlockchainEvent = new MockBlockchainEvent(this, log);
        applicationEventPublisher.publishEvent(mockBlockchainEvent);
    }

}
