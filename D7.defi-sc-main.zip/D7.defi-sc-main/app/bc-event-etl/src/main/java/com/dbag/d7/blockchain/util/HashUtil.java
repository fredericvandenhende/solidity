package com.dbag.d7.blockchain.util;

import org.bouncycastle.jcajce.provider.digest.Keccak;

public class HashUtil {

    public static byte[] hashAsKeccak(byte[] input) {
        Keccak.Digest256 digest256 = new Keccak.Digest256();
        return digest256.digest(input);
    }
}
