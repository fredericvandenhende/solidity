package com.dbag.d7.kafka.service.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class BlockchainEventProducerService {
    private final JsonProducerService producerService;

    //topic for decoded blockchain events
    @Value(value = "${blockchain-event.response.topic}")
    private String blockchainEventTopic;

    @Autowired
    public BlockchainEventProducerService(JsonProducerService producerService) {
        this.producerService = producerService;
    }

    public void sendMessage(String message) {
        producerService.sendMessage(blockchainEventTopic, message);

    }
}
