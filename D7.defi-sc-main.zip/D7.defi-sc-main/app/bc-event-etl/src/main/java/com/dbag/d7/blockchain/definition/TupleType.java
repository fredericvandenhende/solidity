package com.dbag.d7.blockchain.definition;

import java.util.ArrayList;
import java.util.List;

public class TupleType extends SolidityType {

    final List<SolidityType> types = new ArrayList<>();

    public TupleType() {
        super("tuple");
    }

    @Override
    public byte[] encode(Object value) {
        return new byte[0];
    }

    @Override
    public Object decode(byte[] encoded, int origOffset) {
        int offset = origOffset;
        Object[] ret = new Object[types.size()];

        for (int i = 0; i < types.size(); i++) {
            SolidityType elementType = types.get(i);
            if (elementType.isDynamicType()) {
                ret[i] = elementType.decode(encoded, origOffset + IntType.decodeInt(encoded, offset).intValue());
            } else {
                ret[i] = elementType.decode(encoded, offset);
            }
            offset += elementType.getFixedSize();
        }
        return ret;
    }
}
