package com.dbag.d7.blockchain.definition;

import com.dbag.d7.blockchain.util.ByteUtil;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public abstract class ArrayType extends SolidityType {
    final SolidityType elementType;

    public ArrayType(String name) {
        super(name);
        elementType = SolidityType.getType(name.substring(0, name.lastIndexOf("[")));
    }

    public static com.dbag.d7.blockchain.definition.ArrayType getType(String typeName) {
        int idx1 = typeName.lastIndexOf("[");
        int idx2 = typeName.lastIndexOf("]");
        if (idx1 + 1 == idx2) {
            return new DynamicArrayType(typeName);
        } else {
            return new StaticArrayType(typeName);
        }
    }

    @Override
    public byte[] encode(Object value) {
        if (value.getClass().isArray()) {
            List<Object> elems = new ArrayList<>();
            for (int i = 0; i < Array.getLength(value); i++) {
                elems.add(Array.get(value, i));
            }
            return encodeList(elems);
        } else if (value instanceof List) {
            return encodeList((List) value);
        } else {
            throw new RuntimeException("List value expected for type " + getName());
        }
    }

    protected byte[] encodeTuple(List l) {
        byte[][] elems;
        if (elementType.isDynamicType()) {
            elems = new byte[l.size() * 2][];
            int offset = l.size() * SolidityType.Int32Size;
            for (int i = 0; i < l.size(); i++) {
                elems[i] = IntType.encodeInt(offset);
                byte[] encoded = elementType.encode(l.get(i));
                elems[l.size() + i] = encoded;
                offset += SolidityType.Int32Size * ((encoded.length - 1) / SolidityType.Int32Size + 1);
            }
        } else {
            elems = new byte[l.size()][];
            for (int i = 0; i < l.size(); i++) {
                elems[i] = elementType.encode(l.get(i));
            }
        }
        return ByteUtil.merge(elems);
    }

    public Object[] decodeTuple(byte[] encoded, int origOffset, int len) {
        int offset = origOffset;
        Object[] ret = new Object[len];

        for (int i = 0; i < len; i++) {
            if (elementType.isDynamicType()) {
                ret[i] = elementType.decode(encoded, origOffset + IntType.decodeInt(encoded, offset).intValue());
            } else {
                ret[i] = elementType.decode(encoded, offset);
            }
            offset += elementType.getFixedSize();
        }
        return ret;
    }


    public SolidityType getElementType() {
        return elementType;
    }

    public abstract byte[] encodeList(List l);
}
