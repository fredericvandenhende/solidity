package com.dbag.d7.blockchain.definition;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class Bytes32Type extends SolidityType {
    public Bytes32Type(String s) {
        super(s);
    }

    public static byte[] decodeBytes32(byte[] encoded, int offset) {
        return Arrays.copyOfRange(encoded, offset, offset + Int32Size);
    }

    @Override
    public byte[] encode(Object value) {
        if (value instanceof Number) {
            BigInteger bigInt = new BigInteger(value.toString());
            return IntType.encodeInt(bigInt);
        } else if (value instanceof String) {
            byte[] ret = new byte[Int32Size];
            byte[] bytes = ((String) value).getBytes(StandardCharsets.UTF_8);
            System.arraycopy(bytes, 0, ret, 0, bytes.length);
            return ret;
        } else if (value instanceof byte[]) {
            byte[] bytes = (byte[]) value;
            byte[] ret = new byte[Int32Size];
            System.arraycopy(bytes, 0, ret, Int32Size - bytes.length, bytes.length);
            return ret;
        }

        throw new RuntimeException("Can't encode java type " + value.getClass() + " to bytes32");
    }

    @Override
    public Object decode(byte[] encoded, int offset) {
        return decodeBytes32(encoded, offset);
    }
}
