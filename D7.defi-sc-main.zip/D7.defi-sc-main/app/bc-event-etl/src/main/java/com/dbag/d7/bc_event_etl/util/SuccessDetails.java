package com.dbag.d7.bc_event_etl.util;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(enumAsRef = true)
public enum SuccessDetails {
    EVENT_RECEIVED("The event was received successfully - %s."),
    ADDRESS_ADDED("Address %s is added successfully."),
    ADDRESS_REMOVED("Address %s is removed successfully.");

    private final String message;
    SuccessDetails(String message) {
        this.message=message;
    }

    public String getMessage() {
        return message;
    }
}

