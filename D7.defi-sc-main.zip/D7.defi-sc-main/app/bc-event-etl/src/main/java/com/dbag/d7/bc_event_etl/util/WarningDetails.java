package com.dbag.d7.bc_event_etl.util;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(enumAsRef = true)
public enum WarningDetails {
    ADDRESS_ALREADY_EXISTS("The address %s is already in the list.");

    private final String message;

    WarningDetails(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
