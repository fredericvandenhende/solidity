package com.dbag.d7.blockchain.definition;

import com.dbag.d7.blockchain.util.ByteUtil;

import java.math.BigInteger;
import java.util.Arrays;

public class IntType extends NumericType {
    public IntType(String name) {
        super(name);
    }

    public static BigInteger decodeInt(byte[] encoded, int offset) {
        return new BigInteger(Arrays.copyOfRange(encoded, offset, offset + Int32Size));
    }

    public static byte[] encodeInt(int i) {
        return encodeInt(new BigInteger(String.valueOf(i)));
    }

    public static byte[] encodeInt(BigInteger bigInt) {
        return ByteUtil.bigIntegerToBytesSigned(bigInt, Int32Size);
    }

    @Override
    public String getCanonicalName() {
        if (getName().equals("int")) return "int256";
        return super.getCanonicalName();
    }

    @Override
    public Object decode(byte[] encoded, int offset) {
        return decodeInt(encoded, offset);
    }

    @Override
    public byte[] encode(Object value) {
        BigInteger bigInt = encodeInternal(value);
        return encodeInt(bigInt);
    }
}
