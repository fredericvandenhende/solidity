package com.dbag.d7.kafka.service.consumer;

import com.dbag.d7.model.BlockchainOutputMessage;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaOutputConsumerService {
    private static final Logger log = LoggerFactory.getLogger(KafkaOutputConsumerService.class);
    /**
     * Kafka listener method that receives and processes messages from the request kafka topic.
     *
     * @param consumerRecord
     */

    @KafkaListener(
            topics = "#{'${response.topic}'}",
            id = "#{'${response.topic}'}",
            groupId = "#{'${output.group.id}'}")
    public void receive(ConsumerRecord<String, BlockchainOutputMessage> consumerRecord) {
        BlockchainOutputMessage BlockchainOutputMessage = consumerRecord.value();
        log.info("Received message payload = {}", BlockchainOutputMessage.toString());
    }

}
