package com.dbag.d7.kafka.service.consumer;

import com.dbag.d7.bucket.service.TransactionTokenDataUpdateService;
import com.dbag.defi.scdeployer.models.TransactionTokenData;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

/**
 * Service class responsible for consuming messages from Kafka topics.
 */
@Service
public class TransactionDataConsumerService {
    private static final Logger log = LoggerFactory.getLogger(TransactionDataConsumerService.class);
    @Autowired
    TransactionTokenDataUpdateService transactionTokenDataUpdateService;

    /**
     * Kafka listener method that receives and processes messages from the request kafka topic.
     *
     * @param consumerRecord
     */
    @KafkaListener(
            topics = "#{'${request.topic}'}",
            id = "#{'${request.topic}'}",
            groupId = "#{'${address.group.id}'}")
    public void receive(ConsumerRecord<String, TransactionTokenData> consumerRecord) {
        TransactionTokenData transactionTokenData = consumerRecord.value();
        log.info("received message payload = {}", transactionTokenData);
        if (transactionTokenData.getContractAddress() == null) {
            log.info("The contract address is empty");
        } else {
            transactionTokenDataUpdateService.processAddressSubscription(transactionTokenData);
        }
    }

}
