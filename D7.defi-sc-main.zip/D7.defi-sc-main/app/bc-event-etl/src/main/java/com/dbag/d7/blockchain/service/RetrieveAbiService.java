package com.dbag.d7.blockchain.service;

import com.dbag.d7.bc_event_etl.util.ErrorDetails;
import com.dbag.d7.kafka.service.producer.OutputMessageProducerService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

@Service
public class RetrieveAbiService {
    @Autowired
    private OutputMessageProducerService producerService;
    private final ObjectMapper mapper = new ObjectMapper();

    private static final Logger logger = LoggerFactory.getLogger(RetrieveAbiService.class);

    /*this service will call the endpoint in order to retrieve abi function related to the address
        for now we will read the only abi function that we have from local file*/

    private static String getAbiFromFile(String filename) throws FileNotFoundException {
        InputStream is = RetrieveAbiService.class.getClassLoader().getResourceAsStream(filename);
        if (is != null) {
            return new BufferedReader(
                    new InputStreamReader(is, StandardCharsets.UTF_8))
                    .lines()
                    .collect(Collectors.joining("\n"));
        } else throw new FileNotFoundException();
    }

    @SneakyThrows
    public String mockRetrieveAbiFromUrl(){
        String responseWithAbi = getAbiFromFile("sampleResponse.json");
        return getAbiFromContractInfo(responseWithAbi);
    }

    public String retrieveAbifromUrl(String url) {
        WebClient client = WebClient.builder()
                .baseUrl(url)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .build();

        Mono<String> response = client.get().exchangeToMono(resp -> {
            if (resp.statusCode().equals(HttpStatus.OK)) {
                return resp.bodyToMono(String.class);
            } else if (resp.statusCode().is4xxClientError()) {
                producerService.sendErrorMessage(ErrorDetails.UNABLE_TO_READ_ABI);
                logger.info("Error calling the endpoint - " + url);
                return Mono.just("Error response");
            } else {
                producerService.sendErrorMessage(ErrorDetails.UNABLE_TO_READ_ABI);
                return resp.createException()
                        .flatMap(Mono::error);
            }
        });
        String contractInfo = response.block();
        logger.info("Response from url - " + url + "-------" + contractInfo);
        return getAbiFromContractInfo(contractInfo);
    }

    @Nullable
    private String getAbiFromContractInfo(String contractInfo) {
        JsonNode actualObj;
        try {
            actualObj = mapper.readTree(contractInfo);
        } catch (JsonProcessingException e) {
            producerService.sendErrorMessage(ErrorDetails.UNABLE_TO_READ_ABI);
            logger.info("Error parsing the abi from response - " + contractInfo);
            return null;
        }
        JsonNode abi = actualObj.get("data").get("contractAbi");
        return abi == null ? null : abi.toString();
    }
}
