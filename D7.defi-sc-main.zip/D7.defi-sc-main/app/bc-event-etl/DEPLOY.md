## How to deploy project to the dev openshift cluster (ephemeral01, nightly and devint environments)

1. You can deploy code from any branch of the project:</br>
   we need to go to jenkins https://jenkins-d7defisc-jenkinsci.apps.ocp.cs.dev.fra.gcp.dbgcloud.io/job/WorkInProgress/job/BUILD/build?delay=0sec </br>
   Change the APP_BRANCH from main to the branch name that you want to build and hit "Build"
2. After build is finished, artifacts will appear in the artifactory:
   https://artifactory.dbgcloud.io/ui/repos/tree/General/d7defisc-docker-dev-local
3. You should set the branch name in this repo. We have one branch per environment (ephemeral01, nightly, devint):</br>
   e.g. for ephemeral env: https://github.deutsche-boerse.de/d7defiscint/cs.environment/blob/d7ephemeral01/VERSIONS/D7DEFISC.xml#L7
4. Go to ArgoCD and sync proper application. They are named like that \<env\>-\<team\>-\<service-name\> </br>
(it should be one app per service and environment.
e.g. d7ephemeral01-d7defi-d7defisc-bc-event-etl):</br>
https://cs-argocd-server-argocd.apps.ocp.cs.dev.fra.gcp.dbgcloud.io/applications/d7ephemeral01-d7defi-d7defisc-bc-event-etl?resource= </br>
You need to hit the sync button for new app to be deployed.
5. If you changed the name of a branch, you should delete the pod corresponding to the old version of the project, </br>
so that openshift could create a new one (otherwise it will update the pod automatically)
   https://console-openshift-console.apps.ocp.cs.dev.fra.gcp.dbgcloud.io/k8s/ns/d7ephemeral01-d7defi-d7defisc/pods


## Additional references:

1. The helm charts  in which we specify what to deploy in each microservice (deployment, service, configmaps, routes, etc) is located in the repo:</br>
   https://github.deutsche-boerse.de/dev-cs-confidential/cs.openshift_d7defisc

2. The repo used by Jenkins to enable/disable what to build </br>
   https://github.deutsche-boerse.de/dev/D7.defi-sc.env/blob/main/common.env#L20