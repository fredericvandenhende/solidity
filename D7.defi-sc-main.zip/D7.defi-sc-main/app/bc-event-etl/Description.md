## BC event ETL current state

BC-event-etl functionality description based on the main use-case flow.</br>
Application consumes events regarding blockchain address/abi subscription.</br>
The topic is deploy.sc.result.v1</br>
The schema is following:</br>
```
{
  "name" : "TransactionTokenData",
  "type": "record",
  "namespace" : "com.dbag.d7.model",
  "fields" : [
    { "name": "transactionRequestId",
      "type": [
        "null",
        "string"
      ],
      "default": null
    },
    { "name": "contractAddress",
      "type": [
        "null",
        "string"
      ],
      "default": null
    },
    { "name": "smartContractUrl",
      "type": [
        "null",
        "string"
      ],
      "default": null
    },
    { "name": "action",
      "type": {
        "type": "enum",
        "name": "Action",
        "symbols": [
          "ADD",
          "REMOVE"
        ]
      }
    },
    { "name": "responseMessage",
      "type": [
        "null",
        "string"],
      "default": null }
  ]
}
```

In the field we get smartContractUrl. Currently, for local testing purposes, we have the sample of response </br>
sampleResponse.json and using it from local file instead of calling the endpoint (until the endpoint is ready).</br>
On the ephemeral environment we are calling endpoint from kafka message.<br/>
When this kafka event is consumed the blockchain_addresses.txt file in the d7-defi-be-ephemeral bucket of</br>
dbg-clearstream-dev-1748d308 is updated. Service is saving address as a key and abi contract as a value in a json format.</br>

Currently, we have a listener that listens to ALL mocked events.</br>

When the event corresponds to address from the address list (from the bucket), service will decode event and emit</br>
message containing event in json format. There is no schema for this, just a topic  d7.defi.bc-event-update.req.v1</br>

The success, error and warn messages are put in the topic **d7.defi.bc-event-etl-output.v1** with following schema:</br>

```
{"name" : "BlockchainOutputMessage",
"type": "record",
"version": "1.0",
"namespace" : "com.dbag.d7.model",
"fields" : [
{"name": "requestTime", "type" : "string" },
{"name" : "status" , "type" : "string" },
{ "name" : "details" , "type" : "string" },
{ "name" : "message" , "type" : "string" }]}
```

In the application we have the following messages:

SUCCESS</br>
* EVENT_RECEIVED("The event was received successfully - %s."),
* ADDRESS_ADDED("Address %s is added successfully."),
* ADDRESS_REMOVED("Address %s is removed successfully.");

WARN</br>
* ADDRESS_ALREADY_EXISTS("The address %s is already in the list.");

ERROR</br>
* UNABLE_TO_DECODE("Impossible to decode the event with existing abi definition"),
* UNABLE_TO_READ_ABI("The abi is malformed or unavailable"),
* INVALID_ADDRESS("There is no valid address in the event."),
* UNABLE_UNSUBSCRIBE("The address %s is not on the list. Unable to unsubscribe."),
* INVALID_KAFKA_MESSAGE("The message does not contain all necessary fields or malformed. The event is - %s");
